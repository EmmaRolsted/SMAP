package movielibrary.Emma.Rolsted.au541800;

import android.os.Parcel;
import android.os.Parcelable;

//Object class, store the movies we wish to display
public class Movie implements Parcelable {
    private String Title;
    private String Rating;
    private Double UserRating;
    private Boolean Watched;
    private String Plot;
    private String Genre;
    private String UserComments;
    private Integer ImgResource;

    public Movie(String title, String rating, Double userRating, Boolean watched, String plot, String genre, String userComments, Integer imgResource) {
        Title = title;
        Rating = rating;
        UserRating = userRating;
        Watched = watched;
        Plot = plot;
        Genre = genre;
        UserComments = userComments;
        ImgResource = imgResource;
    }

    public Movie()
    {

    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getRating() {
        return Rating;
    }

    public void setRating(String rating) {
        Rating = rating;
    }

    public Double getUserRating() {
        return UserRating;
    }

    public void setUserRating(Double userRating) {
        UserRating = userRating;
    }

    public Boolean getWatched() {
        return Watched;
    }

    public void setWatched(Boolean watched) {
        Watched = watched;
    }

    public String getPlot() {
        return Plot;
    }

    public void setPlot(String plot) {
        Plot = plot;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }

    public String getUserComments() {
        return UserComments;
    }

    public void setUserComments(String userComments) {
        UserComments = userComments;
    }

    public Integer getImgResource() {
        return ImgResource;
    }

    public void setImgResource(Integer imgResource) {
        ImgResource = imgResource;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.Title);
        dest.writeString(this.Rating);
        dest.writeValue(this.UserRating);
        dest.writeValue(this.Watched);
        dest.writeString(this.Plot);
        dest.writeString(this.Genre);
        dest.writeString(this.UserComments);
        dest.writeValue(this.ImgResource);
    }

    protected Movie(Parcel in) {
        this.Title = in.readString();
        this.Rating = in.readString();
        this.UserRating = (Double) in.readValue(Double.class.getClassLoader());
        this.Watched = (Boolean) in.readValue(Boolean.class.getClassLoader());
        this.Plot = in.readString();
        this.Genre = in.readString();
        this.UserComments = in.readString();
        this.ImgResource = (Integer) in.readValue(Integer.class.getClassLoader());
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}
