package movielibrary.Emma.Rolsted.au541800;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/*
//The following videos are used as inspiration:
https://www.youtube.com/watch?v=SLFrwl1hFcw
https://www.youtube.com/watch?v=E6vE8fqQPTE
https://www.youtube.com/watch?v=cKUxiqNB5y0
*/

class MovieListAdapter extends ArrayAdapter<Movie> {

    static class ViewHolder {
        TextView title;
        TextView rating;
        TextView userRating;
        TextView status;
        ImageView img;
    }

    public MovieListAdapter(Context context, int resource, ArrayList<Movie> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Movie movie = (Movie)getItem(position);

        //final View result;
        ViewHolder holder;

        if(convertView == null)
        {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.listview_layout, parent, false);
            holder = new ViewHolder();
            holder.title = convertView.findViewById(R.id.Title);
            holder.rating = convertView.findViewById(R.id.Rating);
            holder.userRating = convertView.findViewById(R.id.UserRating);
            holder.status = convertView.findViewById(R.id.WatchedStatus);
            holder.img = convertView.findViewById(R.id.MovieImg);

            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.title.setText(movie.getTitle());
        holder.rating.setText(String.format("%s%s", getContext().getString(R.string.IMDB), movie.getRating()));
        holder.userRating.setText(getContext().getString(R.string.UserRating) + String.valueOf(movie.getUserRating()));
        holder.img.setImageResource(movie.getImgResource());

        if (!movie.getWatched())
        {
            holder.status.setText(getContext().getString(R.string.Status_false));
            //holder.status.setTextColor();
        }
        else{
            holder.status.setText(getContext().getString(R.string.Status_true));
        }

        if(movie.getUserRating().equals(0.0))
        {
            holder.userRating.setText(getContext().getString(R.string.UserRating));
        }

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailsIntent = new Intent(getContext(), DetailsAcivity.class);
                detailsIntent.putExtra(MainActivity.DETAIL_CONTENT, (Movie) getItem(position));
                detailsIntent.putExtra(MainActivity.POSITION_KEY, position);
                if(getContext() instanceof MainActivity)
                {
                    ((MainActivity) getContext()).ToDetailActivity(detailsIntent);
                }
            }
        });
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent editIntent = new Intent(getContext(), EditAcivity.class);
                editIntent.putExtra(MainActivity.EDIT_CONTENT, (Movie) getItem(position));
                editIntent.putExtra(MainActivity.POSITION_KEY, position);
                if(getContext() instanceof MainActivity)
                {
                    ((MainActivity) getContext()).ToEditActivity(editIntent);
                }
                return true;
            }
        });

        return convertView;
    }
}
