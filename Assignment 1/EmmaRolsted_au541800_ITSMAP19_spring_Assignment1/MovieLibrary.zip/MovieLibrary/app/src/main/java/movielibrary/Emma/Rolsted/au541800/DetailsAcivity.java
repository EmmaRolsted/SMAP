package movielibrary.Emma.Rolsted.au541800;

import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;



import static android.text.Layout.JUSTIFICATION_MODE_INTER_WORD;

public class DetailsAcivity extends AppCompatActivity {
    TextView title, rating, userRating, plot, userComments, genres, status;
    ImageView img;
    Button OK;
    CheckBox movieStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details_acivity);
        Initialize();

        OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_OK);
                finish();
            }
        });

        Movie m = getIntent().getExtras().getParcelable(MainActivity.DETAIL_CONTENT);

        title.setText(m.getTitle());
        rating.setText((getString(R.string.IMDB)+m.getRating()));
        if(m.getUserRating() == 0.0)
        {
            userRating.setText(String.format("%s%s", getString(R.string.User), getString(R.string.none)));
        }
        else
        {
            userRating.setText(String.format("%s%s", getString(R.string.User), String.valueOf(m.getUserRating())));
        }

        movieStatus.setChecked(m.getWatched());
        status.setText(getString(R.string.Status_true));
        plot.setText(m.getPlot());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            plot.setJustificationMode(JUSTIFICATION_MODE_INTER_WORD);
        }
        genres.setText(m.getGenre());
        if(m.getUserComments().isEmpty())
        {
            userComments.setText("");
        }
        else {
            userComments.setText(String.format("%s%s", getString(R.string.UC), m.getUserComments()));
        }
        img.setImageResource(m.getImgResource());
    }
    public void Initialize()
    {
        title = findViewById(R.id.TitleDetails);
        rating = findViewById(R.id.RatingDetails);
        userRating = findViewById(R.id.UserRatingDetails);
        plot = findViewById(R.id.PlotDetails);
        userComments = findViewById(R.id.UserCommentsDetails);
        genres = findViewById(R.id.GenreDetails);
        status = findViewById(R.id.StatusDetails);

        img = findViewById(R.id.ImgDetails);
        OK = findViewById(R.id.ok);

        movieStatus = findViewById(R.id.cbDetails);
    }
}
