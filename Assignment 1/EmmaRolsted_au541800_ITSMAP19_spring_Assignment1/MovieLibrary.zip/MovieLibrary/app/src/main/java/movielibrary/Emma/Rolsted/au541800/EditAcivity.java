package movielibrary.Emma.Rolsted.au541800;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import static movielibrary.Emma.Rolsted.au541800.MainActivity.EDIT_CONTENT;
import static movielibrary.Emma.Rolsted.au541800.MainActivity.EDIT_RESULT;
import static movielibrary.Emma.Rolsted.au541800.MainActivity.POSITION_KEY;

public class EditAcivity extends AppCompatActivity {

    Button cancel, OKEdit;
    EditText userComments;
    SeekBar userRatingSB;
    CheckBox cbStatus;
    TextView userRatingTxt, movieStatus, movieTitle;

    Movie m = new Movie();
    int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_acivity);
        Initialize();

        m = getIntent().getExtras().getParcelable(EDIT_CONTENT);
        pos = getIntent().getExtras().getInt(POSITION_KEY);
        movieTitle.setText(m.getTitle());
        userRatingTxt.setText(String.format("%s%s", getString(R.string.User), String.valueOf(m.getUserRating())));
        cbStatus.setChecked(m.getWatched());
        movieStatus.setText(getString(R.string.Status_true));
        userComments.setText(m.getUserComments());
        double r = Double.valueOf(m.getUserRating());
        userRatingSB.setProgress((int)r * 10);

        userRatingSB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                double rating = progress / 10.0;
                m.setUserRating(rating);
                userRatingTxt.setText((getString(R.string.User)+String.valueOf(rating)));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        OKEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                m.setUserComments(userComments.getText().toString());
                if(cbStatus.isChecked())
                {
                    m.setWatched(true);
                }
                else
                {
                    m.setWatched(false);
                }
                Intent resultIntent = new Intent();
                resultIntent.putExtra(POSITION_KEY, pos);
                resultIntent.putExtra(EDIT_RESULT, m);
                setResult(RESULT_OK,resultIntent);
                finish();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }

    public void Initialize() {
        cancel = findViewById(R.id.CancelEdit);
        OKEdit = findViewById(R.id.okEdit);
        userComments = findViewById(R.id.UserCommentsEdit);
        userRatingSB = findViewById(R.id.SeekBarUREdit);
        userRatingSB.setMax(100);
        cbStatus = findViewById(R.id.cbEdit);
        userRatingTxt = findViewById(R.id.UserRatingEdit);
        movieStatus = findViewById(R.id.StatusEdit);
        movieTitle = findViewById(R.id.TitleEdit);
    }
}
