package movielibrary.Emma.Rolsted.au541800;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list;
    Button exit;
    MovieListAdapter movieAdapter;

    // Request constants
    public static final int DETAIL_REQUEST = 100;
    public static final int EDIT_REQUEST = 101;

    // Result constants
    public static final String EDIT_RESULT = "editResult";
    public static final String POSITION_KEY = "positionOfList";

    public static final String EDIT_CONTENT = "editContents";
    public static final String DETAIL_CONTENT = "detailContents";
    public static final String SAVED_KEY = "savedKey";

    ArrayList<Movie> movieList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(savedInstanceState != null)
        {
            movieList = savedInstanceState.getParcelableArrayList(SAVED_KEY);
        }
        else
        {
            CreateMovie();
        }
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.listview);
        exit = findViewById(R.id.Exit);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });

        movieAdapter = new MovieListAdapter(this, R.layout.listview_layout, movieList);
        list.setAdapter(movieAdapter);
    }

    public void ToDetailActivity(Intent intent)
    {
        startActivityForResult(intent, DETAIL_REQUEST);
    }

    public void ToEditActivity(Intent intent)
    {
        startActivityForResult(intent, EDIT_REQUEST);
    }

    public void CreateMovie()
    {
        Movie movie1 = new Movie("Avengers: The Infinity War",
                "8.5",
                0.0,
                false,
                "The Avengers and their allies must be willing to sacrifice all in an attempt to defeat the powerful Thanos before his blitz of devastation and ruin puts an end to the universe.",
                "Action, Adventure, Fantasy, Sci-Fi",
                "",
                R.drawable.hero_m);
        Movie movie2 = new Movie(
                "Bohemian Rhapsody",
                "8.3",
                0.0,
                false,
                "The story of the legendary rock band Queen and lead singer Freddie Mercury, leading up to their famous performance at Live Aid (1985).",
                "Biography, Drama, Music",
                "",
                R.drawable.music_m);
        Movie movie3 = new Movie(
                "A Star is Born",
                "7.9",
                0.0,
                false,
                "A musician helps a young singer find fame, even as age and alcoholism send his own career into a downward spiral.",
                "Drama, Music Romance",
                "",
                R.drawable.romance_m);
        Movie movie4 = new Movie(
                "Deadpool 2",
                "7.8",
                0.0,
                false,
                "Foul-mouthed mutant mercenary Wade Wilson (AKA. Deadpool), brings together a team of fellow mutant rogues to protect a young boy with supernatural abilities from the brutal, time-traveling cyborg, Cable.",
                "Action, Adventure, Comedy, Sci-Fi",
                "",
                R.drawable.comedy_m);
        Movie movie5 = new Movie(
                "Incredibles 2",
                "7.8",
                0.0,
                false,
                "The Incredibles hero family takes on a new mission, which involves a change in family roles: Bob Parr (Mr Incredible) must manage the house while his wife Helen (Elastigirl) goes out to save the world.",
                "Animation, Action, Adventure, Comedy, Family, Sci-Fi",
                "",
                R.drawable.sci_fi_m);
        Movie movie6 = new Movie(
                "Mission: Impossible - Fallout",
                "7.8",
                0.0,
                false,
                "Ethan Hunt and his IMF team, along with some familiar allies, race against time after a mission gone wrong.",
                "Action, Adventure, Thriller",
                "",
                R.drawable.action_m);
        Movie movie7 = new Movie(
                "Creed II",
                "7.5",
                0.0,
                false,
                "Under the tutelage of Rocky Balboa, heavyweight contender Adonis Creed faces off" +
                        " against Viktor Drago, son of Ivan Drago",
                "Drama, Sport",
                "",
                R.drawable.sport_m);
        Movie movie8 = new Movie(
                "Ready Player One",
                "7.5",
                0.0,
                false,
                "When the creator of a virtual reality world called the OASIS dies, he releases a video in which he challenges all OASIS users to find his Easter Egg, which will give the finder his fortune.",
                "Action, Adventure, Sci-fi",
                "",
                R.drawable.sci_fi_m);
        Movie movie9 = new Movie(
                "First Man",
                "7.5",
                0.0,
                false,
                "A look at the life of the astronaut, Neil Armstrong, and the legendary space mission that led him to become the first man to walk on the Moon on July 20, 1969.",
                "Biography, Drama, History",
                "",
                R.drawable.drama_m);
        Movie movie10 = new Movie(
                "Black Panther",
                "7.4",
                0.0,
                false,
                "T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future and must confront a challenger from his country's past.",
                "Action, Adventure, Sci-Fi\n",
                "",
                R.drawable.hero_m);
        Movie movie11 = new Movie(
                "Aquaman",
                "7.4",
                0.0,
                false,
                "Arthur Curry, the human-born heir to the underwater kingdom of Atlantis, goes on a quest to prevent a war between the worlds of ocean and land.\n",
                "Action, Adventure, Fantasy, Sci-Fi",
                "",
                R.drawable.hero_m);

        movieList.add(movie1);
        movieList.add(movie2);
        movieList.add(movie3);
        movieList.add(movie4);
        movieList.add(movie5);
        movieList.add(movie6);
        movieList.add(movie7);
        movieList.add(movie8);
        movieList.add(movie9);
        movieList.add(movie10);
        movieList.add(movie11);
    }

    public void close()
    {
        finish();
        System.exit(0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == EDIT_REQUEST && resultCode == RESULT_OK)
        {
            Movie m = data.getExtras().getParcelable(EDIT_RESULT);
            int index = data.getExtras().getInt(POSITION_KEY);
            //movieList.remove(movieAdapter.getItem(index));
            movieAdapter.remove(movieAdapter.getItem(index));
            movieAdapter.insert(m, index);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(SAVED_KEY, movieList);
    }
}
