package com.example.smapproject.Views.Food;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.smapproject.Models.FoodOption;
import com.example.smapproject.R;
import com.google.android.material.tabs.TabLayout;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class FoodFragment extends Fragment {

    ViewPager viewPager;
    TabLayout tabLayout;
    FoodAdapter adapter;
    ArrayList<FoodOption> foodOptions = new ArrayList<>();

    private int savedPosition;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.food_fragment, container, false);

        try {
            readData();
        } catch (IOException e) {
            e.printStackTrace();
        }

        adapter = new FoodAdapter(foodOptions, getActivity());
        viewPager = view.findViewById(R.id.foodViewPager);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                savedPosition = position;
                Log.d("FoodFragment:", "position (onpageselected): "+savedPosition);
                saveData();
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        viewPager.setAdapter(adapter);

        tabLayout = view.findViewById(R.id.tabs);

        tabLayout.setupWithViewPager(viewPager);
        loadData();
        Log.d("FoodFragment:", "position (OncreateView): "+savedPosition);
        updateView();

        return view;
    }

    public void readData() throws IOException {
        //Inspiration from: https://stackoverflow.com/questions/19974708/reading-csv-file-in-resources-folder-android
        InputStreamReader is = new InputStreamReader(getContext().getAssets().open("food_options.csv"));
        BufferedReader reader = new BufferedReader(is);
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                FoodOption option = new FoodOption();
                String[] splitted = line.split(";");
                option.setFoodTitle(splitted[0]);
                option.setOpeningHours(splitted[1]);
                option.setDescription(splitted[2]);
                option.setMoreInfo(splitted[3]);
                option.setImgUrl(splitted[4]);
                option.setWebsiteUrl(splitted[5]);
                foodOptions.add(option);
            }
        }
        catch (IOException e) {
            e.printStackTrace(); }
    }

    public void saveData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("save", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt("Position", viewPager.getCurrentItem());
        Log.d("FoodFragment:", "position (savedata): "+savedPosition);
        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("save",
                Context.MODE_PRIVATE);
        savedPosition = sharedPreferences.getInt("Position",0);
        Log.d("FoodFragment:", "position(load): "+savedPosition);
    }

    public void updateView() {
        viewPager.setCurrentItem(savedPosition);
        Log.d("FoodFragment:", "position (update): "+savedPosition);
    }
}
