package com.example.smapproject.Models;

import android.os.Build;

import java.io.Serializable;
import java.util.Objects;

public class CheckListItem implements Serializable {

    private String Content;
    private boolean isChecked;

    public CheckListItem(){}

    public CheckListItem(String content, boolean isChecked) {
        Content = content;
        this.isChecked = isChecked;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CheckListItem)) return false;
        CheckListItem that = (CheckListItem) o;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            return Objects.equals(getContent(), that.getContent());
        }
        return false;
    }


}
