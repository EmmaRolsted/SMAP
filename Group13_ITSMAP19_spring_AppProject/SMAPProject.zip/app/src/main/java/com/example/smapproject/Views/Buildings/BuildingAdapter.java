package com.example.smapproject.Views.Buildings;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.example.smapproject.Models.Building;
import com.example.smapproject.R;

import java.util.ArrayList;

//References:
// https://www.youtube.com/watch?v=e89H29HIkiE
// https://www.youtube.com/watch?v=N9OiUbFEdsg

import androidx.annotation.Nullable;
import androidx.viewpager.widget.PagerAdapter;

//Reference (inspiration from):
// https://www.youtube.com/watch?v=UsXv6VRqZKs
public class BuildingAdapter extends PagerAdapter{

    private ArrayList<Building> buildings;
    private LayoutInflater inflater;
    private Context context;

    //Link to pdf file
    private String pdf = "http://ase.medarbejdere.au.dk/fileadmin/www.ase.au.dk/Filer/Profil/Lokaleoversigt_Finlandsgade_22.pdf";

    public BuildingAdapter(ArrayList<Building> buildings, Context context) {
        this.buildings = buildings;
        this.context = context;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return buildings.get(position).getTitle();
    }

    @Override
    public int getCount() {
        return buildings.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        inflater = LayoutInflater.from(context);
        View view =inflater.inflate(R.layout.buildings_fragment, container, false);

        final Building building = buildings.get(position);

        TextView buildingName, buildingAddress, buildingDescription;
        ImageView buildingImg;
        Button downloadBnt;

        buildingName = view.findViewById(R.id.BuildingCardName);
        buildingImg = view.findViewById(R.id.BuildingCardImg);
        buildingAddress = view.findViewById(R.id.BuildingCardAddress);
        buildingDescription = view.findViewById(R.id.BuildingCardDescription);
        downloadBnt = view.findViewById(R.id.downLoad);

        buildingName.setText(building.getTitle());
        buildingAddress.setText(building.getAddress());
        buildingDescription.setText(building.getDescription());
        Glide.with(context.getApplicationContext()).load(building.getImgURL()).into(buildingImg);

        downloadBnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(pdf));
                context.startActivity(intent);
            }
        });

        container.addView(view,0);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }
}
