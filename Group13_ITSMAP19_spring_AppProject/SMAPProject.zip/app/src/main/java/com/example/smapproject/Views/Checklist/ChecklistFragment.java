package com.example.smapproject.Views.Checklist;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.example.smapproject.Models.CheckListItem;
import com.example.smapproject.R;
import com.example.smapproject.Services.UserService;

import java.util.ArrayList;
import java.util.List;

public class ChecklistFragment extends Fragment implements CheckListInterface {

    private ListView checklistListView;
    private ChecklistAdapter checklistAdapter;
    private ArrayList<CheckListItem> checklistItems = new ArrayList<>();

    private ServiceConnection userServiceConnection;
    private UserService userService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checklist_listview, container, false);

        checklistListView = view.findViewById(R.id.checklistList);

        userServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                UserService.ServiceBinder serviceBinder = (UserService.ServiceBinder) service;
                userService = serviceBinder.getService();

                List<CheckListItem> userChecklist = userService.getUser().getCheckListItems();

                if(userChecklist != null){
                    checklistItems.clear();
                    checklistItems = new ArrayList<>(userChecklist);
                    checklistAdapter = new ChecklistAdapter(getActivity(), R.layout.checklist_fragment, checklistItems, ChecklistFragment.this);
                    checklistListView.setAdapter(checklistAdapter);
                }else{
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_computer),
                            false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_StudentID)
                            ,false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_books),
                            false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_toolbox),
                            false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_IDA),
                            false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_AU_mail),
                            false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_SU),
                            false));
                    checklistItems.add(new CheckListItem(getActivity().getString(R.string.checklist_BB),
                            false));
                    checklistAdapter = new ChecklistAdapter(getActivity(), R.layout.checklist_fragment, checklistItems, ChecklistFragment.this);
                    checklistListView.setAdapter(checklistAdapter);
                    userService.UpdateUser(checklistItems);
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                userService = null;
            }
        };

        getActivity().bindService(new Intent(getContext(), UserService.class), userServiceConnection, Context.BIND_AUTO_CREATE);

        return view;
    }

    @Override
    public void onDestroy() {
        getActivity().unbindService(userServiceConnection);
        super.onDestroy();
    }

    @Override
    public void ChecklistUpdated(CheckListItem item) {
        int index = checklistItems.indexOf(item);
        CheckListItem checkListItemToBeUpdated = checklistItems.get(index);
        checkListItemToBeUpdated.setChecked(item.isChecked());

        userService.UpdateUser(checklistItems);
    }
}


