package com.example.smapproject.Views.Weather;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smapproject.Models.FAQ.FAQ;
import com.example.smapproject.R;
import com.example.smapproject.Services.FAQService;
import com.example.smapproject.Views.FAQ.FAQAdapter;
import com.example.smapproject.Views.FAQ.FaqFragment;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.List;

public class WeatherFragment extends Fragment {

    private ServiceConnection FAQServiceConnection;
    private BroadcastReceiver onBackgroundServiceResult;
    private FAQService faqService;

    private TextView txtCity;
    private TextView txtWeatherInfo;
    private TextView txtCurrentDegree;
    private TextView txtMinMaxDegree;

    private ImageView imgWeather;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.weather_fragment, container, false);

        txtCity = view.findViewById(R.id.txtCity);
        txtWeatherInfo = view.findViewById(R.id.txtWeatherInfo);
        txtCurrentDegree = view.findViewById(R.id.txtCurrentDegree);
        txtMinMaxDegree = view.findViewById(R.id.txtMinMaxDegree);

        imgWeather = view.findViewById(R.id.imgWeather);

        setupServiceConnection();
        setupBroadCastReceiver();
        Intent intent = new Intent(getContext(), FAQService.class);
        getActivity().bindService(intent, FAQServiceConnection, Context.BIND_AUTO_CREATE);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onDestroy() {
        getActivity().unbindService(FAQServiceConnection);
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        Intent intent = new Intent(getContext(), FAQService.class);
        getActivity().bindService(intent, FAQServiceConnection, Context.BIND_AUTO_CREATE);
        IntentFilter filter = new IntentFilter();
        filter.addAction(FAQService.BROADCAST_FAQ_RESULT);
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(onBackgroundServiceResult, filter);
    }

    private void setupServiceConnection() {
        FAQServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                FAQService.ServiceBinder serviceBinder = (FAQService.ServiceBinder) service;
                faqService = serviceBinder.getService();
                faqService.getWeatherData();

            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                faqService = null;
            }
        };
    }

    private void setupBroadCastReceiver() {
        if (onBackgroundServiceResult == null) {
            onBackgroundServiceResult = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, final Intent intent) {
                    String result = intent.getStringExtra(FAQService.SERVICE_RESULT);
                    if (result != null && faqService != null) {
                        if (result.equals(FAQService.BROADCAST_FAQ_WEATHER)) {
                            txtCity.setText(faqService.weather.getCity());

                            DecimalFormat df = new DecimalFormat("#");
                            df.setRoundingMode(RoundingMode.CEILING);
                            df.format(faqService.weather.getCurrentDegree());
                            txtCurrentDegree.setText(""+df.format(faqService.weather.getCurrentDegree())+"°");
                            txtMinMaxDegree.setText(df.format(faqService.weather.getMinDegree()) + "°/" + df.format(faqService.weather.getMaxDegree())+"°");
                            txtWeatherInfo.setText(faqService.weather.getWeatherType());

                            int id = context.getResources().getIdentifier(faqService.weather.getImgUrl(), "drawable", context.getPackageName());
                            imgWeather.setImageResource(id);
                        }
                    }
                }
            };
        }
    }

}
