package com.example.smapproject.Services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.room.Room;

import com.example.smapproject.Database.Database;
import com.example.smapproject.Models.CheckListItem;
import com.example.smapproject.Models.User.User;
import com.example.smapproject.R;
import com.example.smapproject.Utils.Const;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class UserService extends Service {

    private static final String TAG = "UserService";
    private static final String ChannelId = "NotificationChannel";
    public static final String SERVICE_RESULT = "UserServiceResult";
    public static String BROADCAST_RESULT = "BROADCAST_RESULT";

    private final IBinder binder = new ServiceBinder();
    private Database database;
    private User user;
    private ArrayList<String> itemContents = new ArrayList<>();

    public void UpdateUser(final ArrayList<CheckListItem> checklistItems) {
        if(user==null)
            return;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: update user started");
                    user.setCheckListItems(checklistItems);
                    database.UserDao().updateUser(user);
                    Log.d(TAG, "Database: update user finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: update user failed");
                }
            }
        }).start();
    }

    public class ServiceBinder extends Binder {
        public UserService getService() {
            return UserService.this;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        database = Room.databaseBuilder(this, Database.class, "UserDB").build();
        createNotificationChannel();
        return super.onStartCommand(intent, flags, startId);
    }

    public void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.app_name);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(ChannelId, name, importance);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(UserService.this, ChannelId)
                .setSmallIcon(R.drawable.au_logo)
                .setContentText(getString(R.string.background_notification))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(UserService.this);
        notificationManager.notify(1, builder.build());

        new LongOperation().execute();
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    private class LongOperation extends AsyncTask<String, String, String> {
    @Override
    protected String doInBackground(String... strings) {
        while (true)
        {
            try {
                Thread.sleep(120000); //Sleep for 2 minutes
                CreateNotification();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


    public void CreateNotification() {
        itemContents.clear();

        if(user == null )
        return;

        List<CheckListItem> checkListItems = user.getCheckListItems();

        if(checkListItems == null)
            return;

        for (CheckListItem item : checkListItems)
            if (item.isChecked() == false) {
                itemContents.add(item.getContent());
            }

        if(itemContents==null || itemContents.size()==0)
            return;
        //Get a random number to use as index
        Random rand = new Random();
        int n = rand.nextInt(itemContents.size());

        String randomItemContent = itemContents.get(n);

        Notification notification =
                new NotificationCompat.Builder(UserService.this, ChannelId)
                        .setSmallIcon(R.drawable.au_logo)
                        .setContentTitle(getApplicationContext().getString(R.string.checklist_notification))
                        .setContentText(randomItemContent)
                        .build();

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(UserService.this);
        notificationManager.notify(2, notification);
    }}


    public void getUserFromDb(final String username) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: get user started");
                    user = database.UserDao().getUser(username);
                    broadcastTaskResult(Const.GETUSER);
                    Log.d(TAG, "Database: get user finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: get user failed");
                }
            }
        }).start();
    }

    public void createUserInDb(final String username, final String password) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: Create user started");
                    User user = new User();
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setLoggedIn(true);
                    UserService.this.user = user;
                    database.UserDao().addUser(user);
                    broadcastTaskResult(Const.CREATEUSER);
                    Log.d(TAG, "Database: Create user finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: Create user failed");

                }

            }
        }).start();
    }

    public void login(final String username, final String password) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: login user started");
                    user = database.UserDao().getUser(username);
                    if (user != null) {
                        if (password.equals(user.getPassword())) {
                            user.setLoggedIn(true);
                            database.UserDao().updateUser(user);
                            broadcastTaskResult(Const.LOGINUSER);
                        } else {
                            broadcastTaskResult(Const.LOGINUSER_WRONG_PASSWORD);
                        }

                    } else {
                        createUserInDb(username, password);
                    }
                    Log.d(TAG, "Database: login user finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: login user failed");

                }
            }
        }).start();
    }

    private void broadcastTaskResult(String result) {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(BROADCAST_RESULT);
        broadcastIntent.putExtra(SERVICE_RESULT, result);
        LocalBroadcastManager.getInstance(this).sendBroadcast(broadcastIntent);
    }

    public User getUser() {
        return user;
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
}
