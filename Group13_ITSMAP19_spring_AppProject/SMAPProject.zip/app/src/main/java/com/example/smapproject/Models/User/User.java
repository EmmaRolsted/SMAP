package com.example.smapproject.Models.User;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import com.example.smapproject.Database.DataConverter;
import com.example.smapproject.Models.CheckListItem;

import java.io.Serializable;
import java.util.List;

@Entity
public class User implements Serializable {

    @NonNull
    @PrimaryKey
    private String username;

    @ColumnInfo(name = "password")
    private String password;

    @ColumnInfo(name = "is_logged_in")
    private boolean isLoggedIn;

    @TypeConverters(DataConverter.class)
    @ColumnInfo(name = "check_list_items")
    private List<CheckListItem> checkListItems;

    @ColumnInfo(name = "notifications_is_enabled")
    private boolean isNotificationsEnabled;

    @Ignore
    public User(){}

    public User(List<CheckListItem> checkListItems, String username, String password, boolean isLoggedIn, boolean isNotificationsEnabled) {
        this.checkListItems = checkListItems;
        this.username = username;
        this.password = password;
        this.isLoggedIn = isLoggedIn;
        this.isNotificationsEnabled = isNotificationsEnabled;
    }

    public List<CheckListItem> getCheckListItems() {
        return checkListItems;
    }

    public void setCheckListItems(List<CheckListItem> checkListItems) {
        this.checkListItems = (checkListItems);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isNotificationsEnabled() {
        return isNotificationsEnabled;
    }

    public void setNotificationsEnabled(boolean notificationsEnabled) {
        isNotificationsEnabled = notificationsEnabled;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }
}
