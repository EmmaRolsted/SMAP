package com.example.smapproject.Models;

public class FoodOption {
    private String ImgUrl;
    private String websiteUrl;
    private String FoodTitle;
    private String Description;
    private String OpeningHours;
    private String MoreInfo;

    public FoodOption() {
    }

    public FoodOption(String imgUrl, String websiteUrl, String foodTitle, String description, String openingHours, String moreInfo) {
        ImgUrl = imgUrl;
        this.websiteUrl = websiteUrl;
        FoodTitle = foodTitle;
        Description = description;
        OpeningHours = openingHours;
        MoreInfo = moreInfo;
    }

    public String getImgUrl() {
        return ImgUrl;
    }

    public void setImgUrl(String imgUrl) {
        ImgUrl = imgUrl;
    }

    public String getWebsiteUrl() {
        return websiteUrl;
    }

    public void setWebsiteUrl(String websiteUrl) {
        this.websiteUrl = websiteUrl;
    }

    public String getFoodTitle() {
        return FoodTitle;
    }

    public void setFoodTitle(String foodTitle) {
        FoodTitle = foodTitle;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getOpeningHours() {
        return OpeningHours;
    }

    public void setOpeningHours(String openinghours) {
        OpeningHours = openinghours;
    }

    public String getMoreInfo() {
        return MoreInfo;
    }

    public void setMoreInfo(String moreInfo) {
        MoreInfo = moreInfo;
    }
}
