package com.example.smapproject.Models;

public class Weather {

    private String city;
    private String countryCode;
    private String weatherType;
    private String imgUrl;
    private String description;

    private double currentDegree;
    private double maxDegree;
    private double minDegree;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getWeatherType() {
        return weatherType;
    }

    public void setWeatherType(String weatherType) {
        this.weatherType = weatherType;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getCurrentDegree() {
        return currentDegree;
    }

    public void setCurrentDegree(double currentDegree) {
        this.currentDegree = currentDegree;
    }

    public double getMaxDegree() {
        return maxDegree;
    }

    public void setMaxDegree(double maxDegree) {
        this.maxDegree = maxDegree;
    }

    public double getMinDegree() {
        return minDegree;
    }

    public void setMinDegree(double minDegree) {
        this.minDegree = minDegree;
    }

}
