package com.example.smapproject.Views.Components;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.example.smapproject.Models.Maps.MapMarkerModel;
import com.example.smapproject.R;

public class MapItemView extends LinearLayout {

    private TextView title;
    private TextView facilities;
    private ImageView image;
    private MapMarkerModel model;

    public MapItemView(Context context) {
        super(context);
    }

    public MapItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        inflate(context, R.layout.maps_item, this);
        bindViews();
    }

    private void bindViews() {
        title = findViewById(R.id.map_item_title);
        facilities = findViewById(R.id.map_item_facilities);
        image = findViewById(R.id.map_item_image);
    }

    public void setupItem(MapMarkerModel model) {
        this.model = model;
        if (!TextUtils.isEmpty(model.getTitle())) {
            title.setText(model.getTitle());
        }

        if (!TextUtils.isEmpty(model.getFacilities())) {
            facilities.setText(model.getFacilities());
        }

        if (!TextUtils.isEmpty(model.getImageUrl())) {
            Glide.with(this)
                    .load(model.getImageUrl())
                    .centerCrop()
                    .into(image);
        }
    }

    public MapMarkerModel getModel() {
        return model;
    }
}
