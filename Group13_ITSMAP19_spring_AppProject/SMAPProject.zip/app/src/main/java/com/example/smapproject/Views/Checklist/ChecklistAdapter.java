package com.example.smapproject.Views.Checklist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.smapproject.Models.CheckListItem;
import com.example.smapproject.R;

import java.util.ArrayList;

public class ChecklistAdapter extends ArrayAdapter<CheckListItem> {
    public CheckListInterface listener;

    static class ViewHolder {
        TextView titleTextView;
        CheckBox checkBox;
    }

    public ChecklistAdapter(Context context, int resource, ArrayList<CheckListItem> objects, CheckListInterface listener) {
        super(context, resource, objects);
        this.listener = listener;
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final CheckListItem checklistItem = getItem(position);

        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.checklist_fragment, parent, false);
            holder = new ViewHolder();
            holder.titleTextView = convertView.findViewById(R.id.TextView_checklist);
            holder.checkBox = convertView.findViewById(R.id.checkbox_checklist);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                //checklistItem.setChecked(isChecked);
                if(isChecked){
                    checklistItem.setChecked(true);
                    listener.ChecklistUpdated(checklistItem);
                }else
                {
                    checklistItem.setChecked(false);
                    listener.ChecklistUpdated(checklistItem);
                }
            }
        });

        holder.titleTextView.setText(checklistItem.getContent());
        holder.checkBox.setChecked((checklistItem.isChecked()));

        return convertView;
    }
}
