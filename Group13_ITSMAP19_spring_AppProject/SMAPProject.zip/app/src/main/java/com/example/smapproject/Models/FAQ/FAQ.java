package com.example.smapproject.Models.FAQ;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class FAQ {

    public FAQ(int id, String FAQAnswer, String FAQQuestion) {
        this.id = id;
        this.FAQAnswer = FAQAnswer;
        this.FAQQuestion = FAQQuestion;
    }

    @NonNull
    @PrimaryKey
    private int id;

    @ColumnInfo(name = "faq_answer")
    private String FAQAnswer;

    @ColumnInfo(name = "faq_question")
    private String FAQQuestion;

    public String getFAQAnswer() {
        return FAQAnswer;
    }

    public void setFAQAnswer(String FAQAnswer) {
        this.FAQAnswer = FAQAnswer;
    }

    public String getFAQQuestion() {
        return FAQQuestion;
    }

    public void setFAQQuestion(String FAQQuestion) {
        this.FAQQuestion = FAQQuestion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}
