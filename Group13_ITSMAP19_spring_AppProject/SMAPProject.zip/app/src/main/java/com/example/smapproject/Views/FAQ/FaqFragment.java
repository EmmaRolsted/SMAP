package com.example.smapproject.Views.FAQ;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smapproject.Models.FAQ.FAQ;
import com.example.smapproject.R;
import com.example.smapproject.Services.FAQService;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class FaqFragment extends Fragment {

    private ServiceConnection FAQServiceConnection;
    private BroadcastReceiver onBackgroundServiceResult;
    private Button btnAdd;
    private FAQService faqService;
    private FAQAdapter adapter;
    private RecyclerView recyclerView;
    private FAQ tmpFAQ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.faq_fragment, container, false);
        btnAdd = view.findViewById(R.id.btnAddNew);
        recyclerView = view.findViewById(R.id.faqRecyclerView);

        setupServiceConnection();
        setupBroadCastReceiver();
        Intent intent = new Intent(getContext(), FAQService.class);
        getActivity().bindService(intent, FAQServiceConnection, Context.BIND_AUTO_CREATE);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                LayoutInflater li = LayoutInflater.from(getContext());
                View promptsView = li.inflate(R.layout.faq_add_new, null);

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getContext());
                alertDialogBuilder.setView(promptsView);

                final EditText inputFAQQuestion = promptsView.findViewById(R.id.txtNewFAQQuestion);
                final EditText inputFAQAnswer = promptsView.findViewById(R.id.txtNewFAQAnswer);

                alertDialogBuilder.setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                TextView txtAnswer = new TextView(getContext());
                                TextView txtQuestion = new TextView(getContext());

                                txtAnswer.setText(inputFAQAnswer.getText());
                                txtQuestion.setText(inputFAQQuestion.getText());

                                if (inputFAQAnswer.getText().toString().length() == 0 || inputFAQQuestion.getText().toString().length() == 0) {
                                    final Snackbar tmpSnack = Snackbar.make(view, R.string.enter_q_and_a, Snackbar.LENGTH_LONG).setActionTextColor(Color.YELLOW);
                                    tmpSnack.setAction("DISMISS", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            tmpSnack.dismiss();
                                        }
                                    });
                                    tmpSnack.show();
                                } else {
                                    faqService.addFAQ(txtAnswer.getText().toString(), txtQuestion.getText().toString());
                                }
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });

                AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.show();
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                Snackbar.make(view, "Deleted: " + adapter.getFAQAt(viewHolder.getAdapterPosition())
                        .getFAQQuestion(), Snackbar.LENGTH_LONG)
                        .setAction("UNDO", new FAQUndoListener())
                        .setActionTextColor(Color.YELLOW).show();

                tmpFAQ = adapter.getFAQAt(viewHolder.getAdapterPosition());
                faqService.deleteFAQ(adapter.getFAQAt(viewHolder.getAdapterPosition()));
            }
        }).attachToRecyclerView(recyclerView);

        return view;
    }

    public class FAQUndoListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            faqService.addFAQ(tmpFAQ.getFAQAnswer(), tmpFAQ.getFAQQuestion());
        }
    }

    @Override
    public void onDestroy() {
        getActivity().unbindService(FAQServiceConnection);
        super.onDestroy();
    }

    @Override
    public void onStart() {
        super.onStart();
        Intent intent = new Intent(getContext(), FAQService.class);
        getActivity().bindService(intent, FAQServiceConnection, Context.BIND_AUTO_CREATE);
        IntentFilter filter = new IntentFilter();
        filter.addAction(FAQService.BROADCAST_FAQ_RESULT);
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(onBackgroundServiceResult, filter);
    }

    public void setList(List<FAQ> faqList) {
        if (adapter != null) {
            adapter.updateList(faqList);
        } else {
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            adapter = new FAQAdapter(faqList);
            recyclerView.setAdapter(adapter);
        }
    }

    private void setupServiceConnection() {
        FAQServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                FAQService.ServiceBinder serviceBinder = (FAQService.ServiceBinder) service;
                faqService = serviceBinder.getService();
                faqService.getFAQs();
                faqService.getWeatherData();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                faqService = null;
            }
        };
    }

    private void setupBroadCastReceiver() {
        if (onBackgroundServiceResult == null) {
            onBackgroundServiceResult = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, final Intent intent) {
                    String result = intent.getStringExtra(FAQService.SERVICE_RESULT);
                    if (result != null && faqService != null) {
                        if (result.equals(FAQService.BROADCAST_FAQ_ADD_FAQ)) {
                            setList(faqService.getFaqList());
                        } else if (result.equals(FAQService.BROADCAST_FAQ_GET_FAQS)) {
                            setList(faqService.getFaqList());
                        }
                    }
                }
            };
        }
    }
}
