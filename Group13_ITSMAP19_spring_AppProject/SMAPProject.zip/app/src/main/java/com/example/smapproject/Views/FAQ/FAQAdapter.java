package com.example.smapproject.Views.FAQ;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.smapproject.Models.FAQ.FAQ;
import com.example.smapproject.R;

import java.util.List;

public class FAQAdapter extends RecyclerView.Adapter<FAQAdapter.FAQBindViewHolder> {

    private List<FAQ> FAQList;

    public FAQAdapter(List<FAQ> tmpList) {
        this.FAQList = tmpList;
    }

    @NonNull
    @Override
    public FAQBindViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.faq_list_item, parent, false);
        return new FAQBindViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull FAQBindViewHolder holder, int position) {
        FAQ tmp = FAQList.get(position);
        if (tmp != null){
            if(tmp.getFAQAnswer() != null && tmp.getFAQQuestion() != null){
                holder.txtQuestion.setText(tmp.getFAQQuestion());
                holder.txtAnswer.setText(tmp.getFAQAnswer());
            }
        }
    }

    public void updateList(List<FAQ> faqList){
        this.FAQList = faqList;
        notifyDataSetChanged();
    }

    public FAQ getFAQAt(int position){
        return FAQList.get(position);
    }

    @Override
    public int getItemCount() {
        return this.FAQList.size();
    }

    public class FAQBindViewHolder extends RecyclerView.ViewHolder {
        private TextView txtAnswer;
        private TextView txtQuestion;


        public FAQBindViewHolder(@NonNull View itemView) {
            super(itemView);
            txtAnswer = itemView.findViewById(R.id.faq_answer);
            txtQuestion = itemView.findViewById(R.id.faq_question);
        }
    }
}

