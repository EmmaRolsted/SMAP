package com.example.smapproject.Views.Introduction;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.smapproject.R;
import com.example.smapproject.Services.WifiService;
import com.example.smapproject.Views.NavigationDrawerActivity;
import com.google.android.material.snackbar.Snackbar;

public class IntroductionFragment extends Fragment {

    private TextView titleText;
    private Button wifiButton;
    private BroadcastReceiver wifiServiceReceiver;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.introduction_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupView();
    }

    @Override
    public void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter();
        filter.addAction(WifiService.WIFI_BROADCAST_RESULT);
        LocalBroadcastManager.getInstance(getContext()).registerReceiver(wifiServiceReceiver, filter);
    }

    private String getUserName() {
        return getArguments() != null ? getArguments().getString(NavigationDrawerActivity.USERNAME_KEY) : null;
    }


    @Override
    public void onDestroy() {
        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(wifiServiceReceiver);
        super.onDestroy();
    }

    private void setupView() {
        bindViews();
        setupBroadCastReceiver();
        String username = getUserName();
        if (username != null) {
            titleText.setText(getString(R.string.welcome_title, username));
        }
        wifiButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), WifiService.class);
                intent.putExtra(WifiService.SSID_KEY, "AU-Guest");
                intent.putExtra(WifiService.PASSWORD_KEY, "");
                getActivity().startService(intent);
            }
        });
    }

    private void bindViews() {
        if (getView() != null) {
            titleText = getView().findViewById(R.id.welcome_title);
            wifiButton = getView().findViewById(R.id.connect_to_wifi_button);
        }
    }

    private void setupBroadCastReceiver() {
        if (wifiServiceReceiver == null) {
            wifiServiceReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, final Intent intent) {
                    String result = intent.getStringExtra(WifiService.WIFI_SERVICE_RESULT);
                    if (result != null && result.equals(WifiService.CONNECTION_SUCCESSFULL)) {
                        Snackbar.make(getView(), getString(R.string.wifi_success), Snackbar.LENGTH_LONG).show();
                    }
                }
            };
        }
    }

}
