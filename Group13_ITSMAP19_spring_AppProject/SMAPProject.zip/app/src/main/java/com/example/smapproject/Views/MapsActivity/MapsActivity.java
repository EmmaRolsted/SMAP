package com.example.smapproject.Views.MapsActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.example.smapproject.Models.Maps.MapMarkerModel;
import com.example.smapproject.R;
import com.example.smapproject.Utils.Const;
import com.example.smapproject.Views.Components.MapItemView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;
import java.util.regex.Pattern;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST = 5954;
    private GoogleMap mMap;
    private MapItemView mapItemView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                LOCATION_PERMISSION_REQUEST);


    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mapItemView = findViewById(R.id.map_item_view);

        if (!mMap.isMyLocationEnabled() && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        }
        LatLng katrinebjerg = new LatLng(56.171894, 10.190644);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(katrinebjerg, 16.0f));

        mMap.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(
                        this, R.raw.style_json)); //set new style to avoid bloated icons

        try {
            readData();
        } catch (IOException e) {
            e.printStackTrace();
        }

        setOnClickListeners();
    }

    private void setOnClickListeners() {
        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                MapMarkerModel model = (MapMarkerModel) marker.getTag();
                mapItemView.setVisibility(View.VISIBLE);
                mapItemView.setupItem(model);
                return false;
            }
        });

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                mapItemView.setVisibility(View.INVISIBLE);
            }
        });

        mapItemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapMarkerModel model = mapItemView.getModel();
                int id = 0;
                String type = model.getType().toUpperCase();
                if (type.equals(Const.BUILDING)) {
                    id = R.id.menu_buildings;
                } else if (type.equals(Const.FOOD)) {
                    id = R.id.menu_food;
                }

                if (id != 0) {
                    setResult(id);
                    finish();
                }
            }
        });
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (mMap != null) {
                    mMap.setMyLocationEnabled(true);
                }
            }
        }
    }

    public void readData() throws IOException {
        //Inspiration from: https://stackoverflow.com/questions/19974708/reading-csv-file-in-resources-folder-android
        InputStreamReader is = new InputStreamReader(getAssets()
                .open("mapdata.csv"));
        BufferedReader reader = new BufferedReader(is);
        reader.readLine();
        String line;
        while ((line = reader.readLine()) != null) {
            MapMarkerModel model = new MapMarkerModel();
            String[] splitted = line.split(Pattern.quote(";"));
            model.setTitle(splitted[0]);
            model.setFacilities(splitted[1]);
            model.setImageUrl(splitted[2]);
            model.setLatitude(splitted[3]);
            model.setLongitude(splitted[4]);
            model.setType(splitted[5]);

            NumberFormat format = NumberFormat.getInstance(Locale.FRANCE); // use french numberformat to allow "," thousands seperator
            try {
                double lat = format.parse(model.getLatitude()).doubleValue();
                double lng = format.parse(model.getLongitude()).doubleValue();
                LatLng latLng = new LatLng(lat, lng);
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.icon(bitmapDescriptorFromVector(findIcon(model.getType().toUpperCase())));

                Marker marker = mMap.addMarker(markerOptions);
                marker.setTag(model);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

    private int findIcon(String type) {
        switch (type) {
            case Const.BUILDING:
                return R.drawable.ic_school_building;
            case Const.FOOD:
                return R.drawable.ic_food_icon;
            case Const.PARKING:
                return R.drawable.ic_parking_icon;
            case Const.BEER:
                return R.drawable.ic_beer_icon;
            default:
                return 0;
        }
    }


    private BitmapDescriptor bitmapDescriptorFromVector(int vectorResId) {
        //inspiration from https://stackoverflow.com/questions/42365658/custom-marker-in-google-maps-in-android-with-vector-asset-icon
        Drawable vectorDrawable = ContextCompat.getDrawable(this, vectorResId);
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

}
