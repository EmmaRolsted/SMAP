package com.example.smapproject.Utils;

import android.app.ActivityManager;
import android.content.Context;

import static androidx.core.content.ContextCompat.getSystemService;

public class ServiceUtils {

    public static boolean isMyServiceRunning(Context context, Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(context, serviceClass);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
}
