package com.example.smapproject.Views.Checklist;

import com.example.smapproject.Models.CheckListItem;

public interface CheckListInterface {
        void ChecklistUpdated(CheckListItem item);
}
