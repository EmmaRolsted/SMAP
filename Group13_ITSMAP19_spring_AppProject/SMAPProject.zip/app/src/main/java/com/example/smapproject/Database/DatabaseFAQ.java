package com.example.smapproject.Database;

import androidx.room.RoomDatabase;

import com.example.smapproject.Models.FAQ.FAQ;
import com.example.smapproject.Models.FAQ.FAQDAO;

@androidx.room.Database(entities = {FAQ.class}, version = 2, exportSchema = false)
public abstract class DatabaseFAQ extends RoomDatabase {

    public abstract FAQDAO FAQDao();
}
