package com.example.smapproject.Models.Maps;

public class MapMarkerModel {

    private String title;
    private String facilities;
    private String imageUrl;
    private String latitude;
    private String longitude;
    private String type;

    public MapMarkerModel(){

    }
    public MapMarkerModel(String title, String facilities, String imageUrl, String latitude, String longitude, String type) {
        this.title = title;
        this.facilities = facilities;
        this.imageUrl = imageUrl;
        this.latitude = latitude;
        this.longitude = longitude;
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFacilities() {
        return facilities;
    }

    public void setFacilities(String facilities) {
        this.facilities = facilities;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
