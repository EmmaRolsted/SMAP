package com.example.smapproject.Views.Buildings;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.smapproject.Models.Building;
import com.example.smapproject.R;
import com.google.android.material.tabs.TabLayout;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class BuildingsFragment extends Fragment {

    //private ListView buildingListView;

    ArrayList<Building> buildings = new ArrayList<>();
    ViewPager buildingViewPager;
    TabLayout buildingTabLayout;
    BuildingAdapter adapter;

    private int savedPosition;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.listview_building_layout, container, false);

        try {
            readData();
        } catch (IOException e) {
            e.printStackTrace();
        }

        adapter = new BuildingAdapter(buildings, getActivity());
        buildingViewPager = view.findViewById(R.id.building_view_pager);
        buildingViewPager.setAdapter(adapter);

        buildingTabLayout = view.findViewById(R.id.tabs_building);
        buildingTabLayout.setupWithViewPager(buildingViewPager);

        buildingViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                savedPosition = position;
                saveData();

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        loadData();
        updateView();
        return view;
    }

    public void readData() throws IOException {
        //Inspiration from: https://stackoverflow.com/questions/19974708/reading-csv-file-in-resources-folder-android
        InputStreamReader is = new InputStreamReader(getContext().getAssets().open("buildings.csv"));
        BufferedReader reader = new BufferedReader(is);
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                Building building = new Building();
                String[] splitted = line.split(";");
                building.setTitle(splitted[0]);
                building.setAddress(splitted[1]);
                building.setDescription(splitted[2]);
                building.setImgURL(splitted[3]);
                buildings.add(building);
            }
        }
        catch (IOException e) {
            e.printStackTrace(); }
    }

    public void saveData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("saveBuilding",
                Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt("PositionBuilding", buildingViewPager.getCurrentItem());
        editor.apply();
    }

    public void loadData() {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("saveBuilding",
                Context.MODE_PRIVATE);
        savedPosition = sharedPreferences.getInt("PositionBuilding",0);
    }

    public void updateView() {
        buildingViewPager.setCurrentItem(savedPosition);
    }
}
