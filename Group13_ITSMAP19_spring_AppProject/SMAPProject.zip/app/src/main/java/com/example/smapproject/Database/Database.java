package com.example.smapproject.Database;

import androidx.room.RoomDatabase;

import com.example.smapproject.Models.User.User;
import com.example.smapproject.Models.User.UserDAO;

@androidx.room.Database(entities = {User.class}, version = 2, exportSchema = false)
public abstract class Database extends RoomDatabase {

    public abstract UserDAO UserDao();

}
