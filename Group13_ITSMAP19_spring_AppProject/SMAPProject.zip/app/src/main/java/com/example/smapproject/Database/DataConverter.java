package com.example.smapproject.Database;

import androidx.room.TypeConverter;

import com.example.smapproject.Models.CheckListItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.List;

public class DataConverter {

    @TypeConverter
    public String fromCheckListItemList(List<CheckListItem> checkListItems) {
        if (checkListItems == null) {
            return (null);
        }
        Gson gson = new Gson();
        Type type = new TypeToken<List<CheckListItem>>() {}.getType();
        return gson.toJson(checkListItems, type);
    }

    @TypeConverter
    public List<CheckListItem> toCheckListItemList(String checkListItemsString) {
        if (checkListItemsString == null) {
            return (null);
        }
        Gson gson = new Gson();
        Type type = new TypeToken<List<CheckListItem>>() {}.getType();
        return gson.fromJson(checkListItemsString, type);
    }
}