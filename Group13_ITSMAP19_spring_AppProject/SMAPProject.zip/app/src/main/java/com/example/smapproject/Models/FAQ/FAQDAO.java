package com.example.smapproject.Models.FAQ;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface FAQDAO {

    @Insert
    void addFAQ(FAQ faq);

    @Update
    void updateFAQ(FAQ faq);

    @Delete
    void deleteFAQ(FAQ faq);

    @Query("SELECT * FROM FAQ WHERE id = :id")
    FAQ getFAQ(int id);

    @Query("SELECT * FROM FAQ")
    List<FAQ> getFAQs();

    @Query("SELECT MAX(id)+1 from FAQ")
    int getNextId();
}

