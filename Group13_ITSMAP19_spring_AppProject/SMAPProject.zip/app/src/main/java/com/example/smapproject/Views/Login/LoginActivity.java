package com.example.smapproject.Views.Login;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.smapproject.R;
import com.example.smapproject.Services.UserService;
import com.example.smapproject.Utils.Const;
import com.example.smapproject.Views.NavigationDrawerActivity;
import com.facebook.stetho.Stetho;
import com.google.android.material.snackbar.Snackbar;

public class LoginActivity extends AppCompatActivity {

    private EditText passwordEdittext;
    private EditText userNameEdittext;
    private ServiceConnection userServiceConnection;
    private UserService userService;
    private BroadcastReceiver onBackgroundServiceResult;
    private SharedPreferences sharedPreferences;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        setupView();
        Stetho.initializeWithDefaults(this);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(onBackgroundServiceResult);
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        if(userServiceConnection != null){
            unbindService(userServiceConnection);
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(onBackgroundServiceResult);
        super.onStop();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, UserService.class);
        bindService(intent, userServiceConnection, Context.BIND_AUTO_CREATE);
        IntentFilter filter = new IntentFilter();
        filter.addAction(UserService.BROADCAST_RESULT);
        LocalBroadcastManager.getInstance(this).registerReceiver(onBackgroundServiceResult, filter);
    }

    //region Setup View
    private void setupView() {
        bindViews();
        setupButton();
        setupBroadCastReceiver();
        setupServiceConnection();
        Intent intent = new Intent(this, UserService.class);
        startService(intent);

        sharedPreferences = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
        String username = sharedPreferences.getString(Const.LOGIN_KEY, null);
        if (username != null) {
            userNameEdittext.setText(username);
            passwordEdittext.requestFocus();
        }
    }


    private void setupServiceConnection() {
        userServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                UserService.ServiceBinder serviceBinder = (UserService.ServiceBinder) service;
                userService = serviceBinder.getService();
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                userService = null;
            }
        };
    }

    private void bindViews() {
        passwordEdittext = findViewById(R.id.password_edittext);
        userNameEdittext = findViewById(R.id.username_edittext);
    }

    private void setupButton() {
        final Button loginBtn = findViewById(R.id.login_button);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String password = passwordEdittext.getText().toString();
                final String username = userNameEdittext.getText().toString();
                if (!TextUtils.isEmpty(password) && !TextUtils.isEmpty(username)) {
                    userService.login(username, password);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(Const.LOGIN_KEY, username).apply();
                } else {
                    Snackbar.make(loginBtn, getString(R.string.missing_credentials), Snackbar.LENGTH_LONG).setAction("CLOSE", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                        }
                    }).show();
                }
            }
        });
    }


    private void setupBroadCastReceiver() {
        if (onBackgroundServiceResult == null) {
            onBackgroundServiceResult = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, final Intent intent) {
                    String result = intent.getStringExtra(UserService.SERVICE_RESULT);
                    if (result != null) {
                        if (result.equals(Const.LOGINUSER) || result.equals(Const.CREATEUSER)) {
                            login();
                        } else if (result.equals(Const.LOGINUSER_WRONG_PASSWORD)) {
                            passwordEdittext.requestFocus();
                            Snackbar.make(passwordEdittext, getString(R.string.wrong_password), Snackbar.LENGTH_LONG).show();
                        }
                    }
                }
            };
        }
    }

    //endregion

    private void login() {
        Intent intent = new Intent(this, NavigationDrawerActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }


}
