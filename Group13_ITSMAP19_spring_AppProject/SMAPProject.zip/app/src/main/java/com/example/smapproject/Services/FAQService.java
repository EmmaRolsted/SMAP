package com.example.smapproject.Services;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.room.Room;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.smapproject.Database.DatabaseFAQ;
import com.example.smapproject.Models.FAQ.FAQ;
import com.example.smapproject.Models.Weather;
import com.example.smapproject.R;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class FAQService extends Service {

    private static final String TAG = "FAQService";
    public static final String SERVICE_RESULT = "FAQServiceResult";
    public static final String SERVICE_FAQ_ID = "SERVICE_FAQ_ID";
    public static final String BROADCAST_FAQ_RESULT = "BROADCAST_FAQ_RESULT";
    public static final String BROADCAST_FAQ_GET_FAQ = "BROADCAST_FAQ_GET_FAQ";
    public static final String BROADCAST_FAQ_GET_FAQS = "BROADCAST_FAQ_GET_FAQS";
    public static final String BROADCAST_FAQ_ADD_FAQ = "BROADCAST_FAQ_ADD_FAQ";
    public static final String BROADCAST_FAQ_WEATHER = "BROADCAST_FAQ_WEATHER";

    private final IBinder binder = new ServiceBinder();
    private DatabaseFAQ database;
    public FAQ faq;
    public List<FAQ> faqList;
    public Weather weather;

    public FAQ getFaq() {
        return faq;
    }

    public List<FAQ> getFaqList() {

        return faqList;
    }

    private RequestQueue mQueue;


    public void getWeatherData() {

        mQueue = Volley.newRequestQueue(this);

        String apiKey = "&APPID=859c64b31ff373f48452c5325e0052bd";
        String baseUrl = "https://api.openweathermap.org/data/2.5/weather?q=";
        final String cityName = "Aarhus";
        final String countryCode = "DK";
        String units = "&units=metric";
        String finalURL = baseUrl + cityName +","+ countryCode + apiKey + units;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, finalURL, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Weather tmpWeather = new Weather();
                            JSONArray weatherList = response.getJSONArray("weather");

                            for (int i = 0; i < weatherList.length(); i++)
                            {
                                JSONObject jsonObject1 = weatherList.getJSONObject(i);
                                tmpWeather.setWeatherType(jsonObject1.optString("main"));
                                tmpWeather.setDescription(jsonObject1.optString("description"));

                                String tmpString = jsonObject1.optString("icon");
                                tmpWeather.setImgUrl("w"+tmpString);
                            }

                            JSONObject jsonObject1 = response.getJSONObject("main");

                            tmpWeather.setCurrentDegree(jsonObject1.optDouble("temp"));
                            tmpWeather.setMinDegree(jsonObject1.optDouble("temp_min"));
                            tmpWeather.setMaxDegree(jsonObject1.optDouble("temp_max"));


                            tmpWeather.setCity(cityName);
                            tmpWeather.setCountryCode(countryCode);

                            weather = tmpWeather;
                            broadcastTaskResult(BROADCAST_FAQ_WEATHER);
                        } catch (JSONException e) {
                            Log.e("JSON", "" + e);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    public class ServiceBinder extends Binder {
        public FAQService getService() {
            return FAQService.this;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        database = Room.databaseBuilder(this, DatabaseFAQ.class, "FAQDB").build();

        super.onCreate();
    }

    public void getFAQ(final int id) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: get FAQ started");
                    faq = database.FAQDao().getFAQ(id);
                    broadcastTaskResult(BROADCAST_FAQ_GET_FAQ);
                    Log.d(TAG, "Database: get FAQ finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: get FAQ failed");
                }
            }
        }).start();
    }

    public void deleteFAQ(final FAQ faq) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: delete FAQ started");
                    database.FAQDao().deleteFAQ(faq);
                    getFAQs();
                    Log.d(TAG, "Database: delete FAQ finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: delete FAQ failed");
                }
            }
        }).start();

    }

    public void getFAQs() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: get FAQs started");
                    faqList = database.FAQDao().getFAQs();
                    if (faqList.isEmpty()) {
                        initFAQ();
                    }
                    broadcastTaskResult(BROADCAST_FAQ_GET_FAQS);
                    Log.d(TAG, "Database: get FAQs finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: get FAQs failed");
                }
            }
        }).start();
    }

    public void initFAQ() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: add FAQ started");
                    addFAQ(getString(R.string.FAQ_answer_1), getString(R.string.FAQ_question_1));
                    Thread.sleep(50);
                    addFAQ(getString(R.string.FAQ_answer_2), getString(R.string.FAQ_question_2));
                    Thread.sleep(50);
                    addFAQ(getString(R.string.FAQ_answer_3), getString(R.string.FAQ_question_3));
                    Thread.sleep(50);
                    addFAQ(getString(R.string.FAQ_answer_4), getString(R.string.FAQ_question_4));
                    Thread.sleep(50);
                    addFAQ(getString(R.string.FAQ_answer_5), getString(R.string.FAQ_question_5));
                    Thread.sleep(50);
                    addFAQ(getString(R.string.FAQ_answer_6), getString(R.string.FAQ_question_6));
                    Thread.sleep(50);
                    addFAQ(getString(R.string.FAQ_answer_7), getString(R.string.FAQ_question_7));
                    getFAQs();
                    Log.d(TAG, "Database: add FAQ finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: add FAQ failed");
                }
            }
        }).start();


    }

    public void addFAQ(final String FAQAnswer, final String FAQQuestion) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(TAG, "Database: add FAQ started");
                    int id = database.FAQDao().getNextId();
                    FAQ faq = new FAQ(id, FAQAnswer, FAQQuestion);
                    database.FAQDao().addFAQ(faq);
                    getFAQs();
                    broadcastTaskResult(BROADCAST_FAQ_ADD_FAQ, faq.getId());

                    Log.d(TAG, "Database: add FAQ finished");
                } catch (Exception e) {
                    Log.d(TAG, "Database: add FAQ failed");
                }
            }
        }).start();
    }

    private void broadcastTaskResult(String result) {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(BROADCAST_FAQ_RESULT);
        broadcastIntent.putExtra(SERVICE_RESULT, result);
        LocalBroadcastManager.getInstance(this).sendBroadcast(broadcastIntent);
    }

    private void broadcastTaskResult(String result, int id) {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(BROADCAST_FAQ_RESULT);
        broadcastIntent.putExtra(SERVICE_RESULT, result);
        broadcastIntent.putExtra(SERVICE_FAQ_ID, id);
        LocalBroadcastManager.getInstance(this).sendBroadcast(broadcastIntent);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }
}
