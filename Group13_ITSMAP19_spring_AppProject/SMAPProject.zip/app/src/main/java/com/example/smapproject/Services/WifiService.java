package com.example.smapproject.Services;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.smapproject.R;
import com.google.android.gms.common.util.CollectionUtils;

import java.util.List;

public class WifiService extends Service {

    public static final String WIFI_BROADCAST_RESULT = "WIFIBROADCAST";
    public static final String WIFI_SERVICE_RESULT = "WIFIRESULT";
    public static final String CONNECTION_SUCCESSFULL = "WIFISUCCES";

    private static final String ChannelId = "NotificationChannel";
    public static final String SSID_KEY = "SSIDKEY";
    public static final String PASSWORD_KEY = "PASSWORDKEY";


    private int RETRIES = 0;

    private Handler handler = new Handler();
    private String SSID;
    private String password;
    private ConnectivityManager manager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private WifiManager wifiManager;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public void onDestroy() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            manager.unregisterNetworkCallback(networkCallback);
        }
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            SSID = intent.getStringExtra(SSID_KEY);
            password = intent.getStringExtra(PASSWORD_KEY);
        }
        handler.post(runnable);
        setupNetworkCallback();
        return super.onStartCommand(intent, flags, startId);
    }

    private void setupNetworkCallback() {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            final ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    super.onAvailable(network);
                    Log.d("WifiService", "Connected to a network");
                    if(wifiManager != null){
                        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                        if(wifiInfo != null && wifiInfo.getSSID() != null && wifiInfo.getSSID().toUpperCase().equals("\"AU-GUEST\"")){
                            Log.d("WifiService", "Connected to AU-Guest");
                            broadcastTaskResult(CONNECTION_SUCCESSFULL);
                        }
                    }
                }

                @Override
                public void onLost(Network network) {
                    super.onLost(network);
                }
            };

            manager.registerDefaultNetworkCallback(networkCallback);

        }

    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

            if (!wifiManager.isWifiEnabled()) {
                wifiManager.setWifiEnabled(true);
            }
            WifiConfiguration wifiConfiguration = findWifiConfig(wifiManager);

            if (wifiConfiguration != null) {
                connectToWifi(wifiManager, wifiConfiguration.networkId); //Connect if network already is configured
            } else {
                WifiConfiguration wifiConf = new WifiConfiguration(); //Configure network with SSID and password
                wifiConf.SSID = "\"" + SSID + "\""; //Must be enclosed with double quotation marks if UTF-8 String according to documentation
                if (!TextUtils.isEmpty(password)) {
                    wifiConf.preSharedKey = "\"" + password + "\"";
                } else {
                    wifiConf.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
                }
                int networkId = wifiManager.addNetwork(wifiConf);
                connectToWifi(wifiManager, networkId);
            }
            handler.removeCallbacksAndMessages(runnable);
        }
    };

    private void connectToWifi(final WifiManager wifiManager, final int networkId) {
        wifiManager.enableNetwork(networkId, true);
        wifiManager.reconnect();
    }

    private WifiConfiguration findWifiConfig(WifiManager wifiManager) {
        List<WifiConfiguration> networkConfigs = wifiManager.getConfiguredNetworks();

        if (!CollectionUtils.isEmpty(networkConfigs)) {
            for (WifiConfiguration currentConfig : networkConfigs) {
                if (currentConfig.SSID != null && currentConfig.SSID.equals("\"" + SSID + "\"")) { //Check if network is already configured
                    return currentConfig;
                }
            }
        }
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.app_name);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(ChannelId, name, importance);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(WifiService.this, ChannelId)
                .setSmallIcon(R.drawable.au_logo)
                .setContentText(getString(R.string.background_notification))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(WifiService.this);
        notificationManager.notify(1, builder.build());
    }

    private void broadcastTaskResult(String result) {
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction(WIFI_BROADCAST_RESULT);
        broadcastIntent.putExtra(WIFI_SERVICE_RESULT, result);
        LocalBroadcastManager.getInstance(this).sendBroadcast(broadcastIntent);
    }


}
