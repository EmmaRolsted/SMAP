package com.example.smapproject.Utils;

public class Const {


    //Db consts
    public static final String GETUSER = "GETUSER";
    public static final String CREATEUSER = "CREATEUSER";
    public static final String UPDATEUSER = "UPDATEUSER";
    public static final String LOGINUSER = "LOGINUSER";
    public static final String LOGINUSER_WRONG_PASSWORD = "LOGINUSER_WRONG_PASSWORD";

    //Map marker types
    public static final String BUILDING = "BUILDING";
    public static final String FOOD = "FOOD";
    public static final String PARKING = "PARKING";
    public static final String BEER = "BEER";


    //shared preferences
    public static final String LOGIN_KEY = "LOGIN";

}
