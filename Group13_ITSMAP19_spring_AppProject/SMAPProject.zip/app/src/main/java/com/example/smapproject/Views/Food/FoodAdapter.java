package com.example.smapproject.Views.Food;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.example.smapproject.Models.FoodOption;
import com.example.smapproject.R;

import java.util.ArrayList;

//Reference (inspiration from):
// https://www.youtube.com/watch?v=UsXv6VRqZKs

public class FoodAdapter extends PagerAdapter {

    private ArrayList<FoodOption> foodOptionList;
    private LayoutInflater inflater;
    private Context context;

    public FoodAdapter(ArrayList<FoodOption> foodOptionList, Context context) {
        this.foodOptionList = foodOptionList;
        this.context = context;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return foodOptionList.get(position).getFoodTitle();
    }

    @Override
    public int getCount() {
        return foodOptionList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        inflater = LayoutInflater.from(context);
        View view =inflater.inflate(R.layout.food_item, container, false);

        final FoodOption option = foodOptionList.get(position);

        ImageView foodImg;
        TextView foodTitle, foodDescription, foodOpeningHours, foodMoreInfo;
        Button link;

        foodImg = view.findViewById(R.id.food_image);
        foodTitle = view.findViewById(R.id.food_title);
        foodDescription = view.findViewById(R.id.food_description);
        foodOpeningHours = view.findViewById(R.id.food_open_time);
        foodMoreInfo = view.findViewById(R.id.food_info);
        link = view.findViewById(R.id.food_website);

        Glide.with(context.getApplicationContext()).load(option.getImgUrl()).into(foodImg);

        foodTitle.setText(option.getFoodTitle());
        foodDescription.setText(option.getDescription());
        foodOpeningHours.setText(option.getOpeningHours());
        foodMoreInfo.setText(option.getMoreInfo());

        container.addView(view,0);

        link.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse(option.getWebsiteUrl()));
                context.startActivity(intent);
            }
        });
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }
}
