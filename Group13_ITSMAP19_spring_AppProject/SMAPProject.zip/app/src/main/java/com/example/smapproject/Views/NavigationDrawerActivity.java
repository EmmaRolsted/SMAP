package com.example.smapproject.Views;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.smapproject.Models.User.User;
import com.example.smapproject.R;
import com.example.smapproject.Services.UserService;
import com.example.smapproject.Views.Buildings.BuildingsFragment;
import com.example.smapproject.Views.Checklist.ChecklistFragment;
import com.example.smapproject.Views.FAQ.FaqFragment;
import com.example.smapproject.Views.Food.FoodFragment;
import com.example.smapproject.Views.Introduction.IntroductionFragment;
import com.example.smapproject.Views.MapsActivity.MapsActivity;
import com.example.smapproject.Views.Weather.WeatherFragment;
import com.google.android.material.navigation.NavigationView;

public class NavigationDrawerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    public static final String USERNAME_KEY = "usernamekey";
    private static final String FRAGMENT_ID_KEY = "FRAGMENTID";

    public static final int MAPS_ACTIVITY_RESULT = 5954;
    private Toolbar toolbar;
    private ServiceConnection userServiceConnection;
    private UserService userService;
    private int fragmentId = 0;


    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navigationdrawer_activity);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageButton fab = findViewById(R.id.google_maps_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NavigationDrawerActivity.this, MapsActivity.class);
                startActivityForResult(intent, MAPS_ACTIVITY_RESULT);
            }
        });


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        Intent intent = new Intent(this, UserService.class);

        userServiceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                UserService.ServiceBinder serviceBinder = (UserService.ServiceBinder) service;
                userService = serviceBinder.getService();
                if (savedInstanceState == null) {
                    startFragment(R.id.menu_introduction);
                } else {
                    startFragment(savedInstanceState.getInt(FRAGMENT_ID_KEY));
                }
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                userService = null;
            }
        };
        bindService(intent, userServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putInt(FRAGMENT_ID_KEY, fragmentId);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        unbindService(userServiceConnection);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            Intent a = new Intent(Intent.ACTION_MAIN);
            a.addCategory(Intent.CATEGORY_HOME);
            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(a);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == MAPS_ACTIVITY_RESULT && resultCode > 0) {
            startFragment(resultCode);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        startFragment(item.getItemId());
        return true;
    }

    private void startFragment(int id) {
        Fragment fragment = null;
        boolean closeDrawer = true;
        Bundle args = new Bundle();
        this.fragmentId = id;

        switch (id) {
            case R.id.menu_introduction:
                fragment = new IntroductionFragment();
                User user = userService.getUser();
                if (user != null) {
                    args.putString(USERNAME_KEY, user.getUsername());
                }
                fragment.setArguments(args);
                toolbar.setTitle(getString(R.string.app_name));
                break;
            case R.id.menu_buildings:
                fragment = new BuildingsFragment();
                toolbar.setTitle(getString(R.string.buildings));
                break;
            case R.id.menu_food:
                fragment = new FoodFragment();
                toolbar.setTitle(getString(R.string.food));
                break;
            case R.id.menu_checklist:
                fragment = new ChecklistFragment();
                toolbar.setTitle(getString(R.string.checklist));
                break;
            case R.id.menu_faq:
                fragment = new FaqFragment();
                toolbar.setTitle(getString(R.string.faq));
                break;
            case R.id.menu_weather:
                fragment = new WeatherFragment();
                toolbar.setTitle(getString(R.string.weather));
                break;
            case R.id.menu_logout:
                finish();
                closeDrawer = false;
                break;
        }

        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout, fragment);
            ft.commit();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START) && closeDrawer) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }
}
