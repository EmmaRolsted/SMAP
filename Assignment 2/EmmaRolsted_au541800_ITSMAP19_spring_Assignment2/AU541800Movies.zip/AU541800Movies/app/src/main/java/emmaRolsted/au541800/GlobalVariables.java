package emmaRolsted.au541800;

public interface GlobalVariables {
    String TAG = "MOVIE_SERVICE";
    String BROADCAST_MOVIES_UPDATED =  "emmaRolsted.au541800.BROADCAST_MOVIES_UPDATED";
    String BROADCAST_MOVIES_CREATED =  "emmaRolsted.au541800.BROADCAST_MOVIES_CREATED";
    String BROADCAST_MOVIE_DELETED =  "emmaRolsted.au541800.BROADCAST_MOVIE_DELETED";
    String CHANNEL_ID = "CHANNEL_2";
    Integer ID = 101;

    String EDIT_CONTENT = "editContents";
    String DETAIL_CONTENT = "detailContents";
    String IMAGE = "image";
    String SAVED_KEY = "Key";


}
