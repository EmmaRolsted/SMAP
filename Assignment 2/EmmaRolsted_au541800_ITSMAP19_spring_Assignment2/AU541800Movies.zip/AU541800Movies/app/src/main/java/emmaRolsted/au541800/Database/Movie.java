package emmaRolsted.au541800.Database;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.util.Objects;


@Entity(tableName = "movie")
public class Movie implements Parcelable {

    public Movie() {
    }

    public Movie(@NonNull String title, String rating, Double userRating, Boolean watched, String plot, String genre, String userComments, Integer imgResource) {
        Title = title;
        Rating = rating;
        UserRating = userRating;
        Watched = watched;
        Plot = plot;
        Genre = genre;
        UserComments = userComments;
        ImgResource = imgResource;
    }

    @PrimaryKey
    @NonNull
    @SerializedName("Title")
    @ColumnInfo(name = "title")
    private String Title;

    @SerializedName("imdbRating")
    @ColumnInfo(name = "rating")
    private String Rating;

    @ColumnInfo(name = "user_rating")
    private Double UserRating = 0.0;

    @ColumnInfo(name = "watched")
    private Boolean Watched = false;

    @SerializedName("Plot")
    @ColumnInfo(name = "plot")
    private String Plot;

    @SerializedName("Genre")
    @ColumnInfo(name = "genre")
    private String Genre;

    @ColumnInfo(name = "user_comments")
    private String UserComments = "";

    @ColumnInfo(name = "img_resource")
    private Integer ImgResource;


    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getRating() {
        return Rating;
    }

    public void setRating(String rating) {
        Rating = rating;
    }

    public Double getUserRating() {
        return UserRating;
    }

    public void setUserRating(Double userRating) {
        UserRating = userRating;
    }

    public Boolean getWatched() {
        return Watched;
    }

    public void setWatched(Boolean watched) {
        Watched = watched;
    }

    public String getPlot() {
        return Plot;
    }

    public void setPlot(String plot) {
        Plot = plot;
    }

    public String getGenre() {
        return Genre;
    }

    public void setGenre(String genre) {
        Genre = genre;
    }

    public String getUserComments() {
        return UserComments;
    }

    public void setUserComments(String userComments) {
        UserComments = userComments;
    }

    public Integer getImgResource() {
        return ImgResource;
    }

    public void setImgResource(Integer imgResource) {
        ImgResource = imgResource;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.Title);
        dest.writeString(this.Rating);
        dest.writeValue(this.UserRating);
        dest.writeValue(this.Watched);
        dest.writeString(this.Plot);
        dest.writeString(this.Genre);
        dest.writeString(this.UserComments);
        dest.writeValue(this.ImgResource);
    }

    protected Movie(Parcel in) {
        this.Title = in.readString();
        this.Rating = in.readString();
        this.UserRating = (Double) in.readValue(Double.class.getClassLoader());
        this.Watched = (Boolean) in.readValue(Boolean.class.getClassLoader());
        this.Plot = in.readString();
        this.Genre = in.readString();
        this.UserComments = in.readString();
        this.ImgResource = (Integer) in.readValue(Integer.class.getClassLoader());
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Movie)) return false;
        Movie movie = (Movie) o;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            return Objects.equals(getTitle(), movie.getTitle());
        }
        return false;
    }

    @Override
    public int hashCode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            return Objects.hash(getTitle(), getRating(), getUserRating(), getWatched(), getPlot(), getGenre(), getUserComments(), getImgResource());
        }
        return 0;
    }
}
