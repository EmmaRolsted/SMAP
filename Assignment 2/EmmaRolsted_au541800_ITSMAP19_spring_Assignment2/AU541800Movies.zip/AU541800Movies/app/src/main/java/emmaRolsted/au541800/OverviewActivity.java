package emmaRolsted.au541800;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.facebook.stetho.Stetho;
import com.facebook.stetho.okhttp3.StethoInterceptor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;

import emmaRolsted.au541800.Database.AppDatabase;
import emmaRolsted.au541800.Database.Movie;
import okhttp3.OkHttpClient;

import static emmaRolsted.au541800.GlobalVariables.*;

public class OverviewActivity extends AppCompatActivity {

    private ListView list;
    private Button exitBnt, AddMovie;
    MovieListAdapter movieAdapter;
    //AppDatabase db;
    private boolean bound = false;

    ArrayList<Movie> movieList = new ArrayList<>();
    MovieService movieService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overview);

        Initialize();

        //Facebook Stetho setup
        Stetho.initializeWithDefaults(this);

        OkHttpClient client =
                new OkHttpClient.Builder().addNetworkInterceptor(new StethoInterceptor()).build();


        Intent serviceIntent = new Intent(this.getApplicationContext(), MovieService.class);
        startService(serviceIntent);


        exitBnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        AddMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bound)
                {
                    OpenDialogbox();
                }
            }
        });

        movieAdapter = new MovieListAdapter(this, R.layout.listview_layout, movieList);
        list.setAdapter(movieAdapter);

    }

    //Ref: https://stackoverflow.com/questions/10903754/input-text-dialog-android
    private void OpenDialogbox()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.InputSearch);

        // Set up the input
        final EditText input = new EditText(this);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Check if movie exits in db:
                if(movieService.GetMovie(input.getText().toString())==null)
                {
                    movieService.AddMovie(input.getText().toString());
                }
                else
                {
                    Toast toast = Toast.makeText(getApplicationContext(),
                            getString(R.string.Toast_database_exists),
                            Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.FailToAdd), Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        builder.show();
    }

    private ServiceConnection movieServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            MovieService.LocalBinder binder = (MovieService.LocalBinder) service;
            movieService = binder.getService();
            bound = true;

            movieList.clear();
            movieAdapter.clear();

            movieList = movieService.GetAllMovies();
            movieAdapter.addAll(movieList);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e("OverviewActivity", "onServiceDisconnected");
            bound = false;
        }
    };


    @Override
    protected void onStart(){
        super.onStart();
        bindToMovieService();

        //Get broadcast results:
        IntentFilter filter = new IntentFilter();
        filter.addAction(BROADCAST_MOVIES_UPDATED);
        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver, filter);
    }

    void bindToMovieService() {
        bindService(new Intent(this.getApplicationContext(),
                MovieService.class), movieServiceConnection, Context.BIND_AUTO_CREATE);
        bound = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        unBindFromMovieService();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
    }

    void unBindFromMovieService() {
        if (bound) {
            unbindService(movieServiceConnection);
            bound = false;
        }
    }

    public void ToDetailActivity(Intent intent)
    {
        startActivity(intent);
    }

    public void ToEditActivity(Intent intent)
    {
        startActivity(intent);
    }

    public void Initialize()
    {
        //Initializing all UI elements
        list = findViewById(R.id.listview);
        exitBnt = findViewById(R.id.Exit);
        AddMovie = findViewById(R.id.AddMovieBnt);
    }

    //Reference:
    //https://gist.github.com/Antarix/8131277
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            movieList.clear();
            movieAdapter.clear();

            movieList = movieService.GetAllMovies();
            movieAdapter.addAll(movieList);
        }
    };
}

