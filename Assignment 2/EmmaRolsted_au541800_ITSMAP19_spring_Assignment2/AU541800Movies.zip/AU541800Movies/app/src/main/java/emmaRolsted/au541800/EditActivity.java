package emmaRolsted.au541800;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

import emmaRolsted.au541800.Database.Movie;

public class EditActivity extends AppCompatActivity {

    private Button cancel, OKEdit;
    private EditText userComments;
    private SeekBar userRatingSB;
    private CheckBox cbStatus;
    private boolean bound = false;
    private TextView userRatingTxt, movieStatus, movieTitle;
    private MovieService movieService;
    String title;
    double rating;

    Movie m = new Movie();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        Initialize();

        title = getIntent().getStringExtra(GlobalVariables.EDIT_CONTENT);

        if(savedInstanceState !=null)
        {

            m =savedInstanceState.getParcelable(GlobalVariables.SAVED_KEY);
            UpdateUI();
        }


        userRatingSB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rating = progress / 10.0;
                m.setUserRating(rating);
                if(rating==10.0){
                    userRatingTxt.setText(String.format("%s%s", getString(R.string.UserRating),
                            getString(R.string.ten)));
                }

                else {
                    userRatingTxt.setText((getString(R.string.UserRating) + String.valueOf(rating)));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        OKEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                m.setUserComments(userComments.getText().toString());
                if(cbStatus.isChecked())
                {
                    m.setWatched(true);
                }
                else
                {
                    m.setWatched(false);
                }
                movieService.UpdateMovie(m);
                finish();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private ServiceConnection movieServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            MovieService.LocalBinder binder = (MovieService.LocalBinder) service;
            movieService = binder.getService();
            bound = true;

            if(m.getUserRating() == 0.0)
            {
                m = movieService.GetMovie(title);
            }

            UpdateUI();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e("EditActivity", "onServiceDisconnected");
            bound = false;
        }
    };

    @Override
    protected void onStart(){
        super.onStart();
        bindToMovieService();
    }

    void bindToMovieService() {
        bindService(new Intent(this.getApplicationContext(),
                MovieService.class), movieServiceConnection, Context.BIND_AUTO_CREATE);
        bound = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        unBindFromMovieService();

    }

    void unBindFromMovieService() {
        if (bound) {
            unbindService(movieServiceConnection);
            bound = false;
        }
    }

    public void UpdateUI()
    {
        movieTitle.setText(m.getTitle());
        userRatingTxt.setText(String.format("%s%s", getString(R.string.UserRating), String.valueOf(m.getUserRating())));
        cbStatus.setChecked(m.getWatched());
        movieStatus.setText(getString(R.string.Status_true));
        userComments.setText(m.getUserComments());
        double r = Double.valueOf(m.getUserRating());
        userRatingSB.setProgress((int)r * 10);
    }


    public void Initialize() {

        //Initializing UI elements
        cancel = findViewById(R.id.CancelEdit);
        OKEdit = findViewById(R.id.okEdit);
        userComments = findViewById(R.id.UserCommentsEdit);
        userRatingSB = findViewById(R.id.SeekBarUREdit);
        userRatingSB.setMax(100);
        cbStatus = findViewById(R.id.cbEdit);
        userRatingTxt = findViewById(R.id.UserRatingEdit);
        movieStatus = findViewById(R.id.StatusEdit);
        movieTitle = findViewById(R.id.TitleEdit);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        m.setUserRating(rating);
        m.setUserComments(userComments.getText().toString());
        if(cbStatus.isChecked())
        {
            m.setWatched(true);
        }
        else
        {
            m.setWatched(false);
        }
        outState.putParcelable(GlobalVariables.SAVED_KEY, m);

    }
}
