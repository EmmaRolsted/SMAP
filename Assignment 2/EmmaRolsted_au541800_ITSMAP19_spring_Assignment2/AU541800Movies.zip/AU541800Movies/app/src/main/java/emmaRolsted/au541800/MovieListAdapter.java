package emmaRolsted.au541800;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import emmaRolsted.au541800.Database.Movie;

import static emmaRolsted.au541800.GlobalVariables.*;

/* References:

The following videos are used as inspiration:
https://www.youtube.com/watch?v=SLFrwl1hFcw
https://www.youtube.com/watch?v=E6vE8fqQPTE
https://www.youtube.com/watch?v=cKUxiqNB5y0
*/

class MovieListAdapter extends ArrayAdapter<Movie> {

    static class ViewHolder {
        TextView title;
        TextView rating;
        TextView userRating;
        TextView status;
        ImageView img;
    }

    public MovieListAdapter(Context context, int resource, ArrayList<Movie> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final Movie movie = (Movie)getItem(position);

        ViewHolder holder;

        if(convertView == null)
        {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.listview_layout, parent, false);
            holder = new ViewHolder();
            holder.title = convertView.findViewById(R.id.Title);
            holder.rating = convertView.findViewById(R.id.Rating);
            holder.userRating = convertView.findViewById(R.id.UserRating);
            holder.status = convertView.findViewById(R.id.WatchedStatus);
            holder.img = convertView.findViewById(R.id.MovieImg);

            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.title.setText(movie.getTitle());
        holder.rating.setText(String.format("%s%s", getContext().getString(R.string.IMDB), movie.getRating()));
        holder.userRating.setText(String.format("%s%s", getContext().getString(R.string.UR), String.valueOf(movie.getUserRating())));

        if (!movie.getWatched())
        {
            holder.status.setText(getContext().getString(R.string.Status_false));
        }
        else{
            holder.status.setText(getContext().getString(R.string.Status_true));
        }

        if(movie.getUserRating().equals(0.0))
        {
            holder.userRating.setText(getContext().getString(R.string.UR));
        }

        if(movie.getUserRating().equals(10.0))
        {
            holder.userRating.setText(String.format("%s%s",getContext().getString(R.string.UR),
                    getContext().getString(R.string.ten)));
        }

        String Genre = movie.getGenre();
        String[] parts = Genre.split(",");
        String PrimaryGenre = parts[0];

        switch (PrimaryGenre){
            case "Action": movie.setImgResource(R.drawable.action);
                break;
            case "Adventure": movie.setImgResource(R.drawable.adventure);
                break;
            case "Animation": movie.setImgResource(R.drawable.animation);
                break;
            case "Biography": movie.setImgResource(R.drawable.biography);
                break;
            case "Comedy": movie.setImgResource(R.drawable.comedy);
                break;
            case "Crime": movie.setImgResource(R.drawable.crime);
                break;
            case "Drama": movie.setImgResource(R.drawable.drama);
                break;
            case "Fantasy": movie.setImgResource(R.drawable.fantasy);
                break;
            case "Horror": movie.setImgResource(R.drawable.horror);
                break;
            case "Music": movie.setImgResource(R.drawable.music);
                break;
            case "Mystery": movie.setImgResource(R.drawable.mystery);
                break;
            case "Romance": movie.setImgResource(R.drawable.romance);
                break;
            case "Sci-Fi": movie.setImgResource(R.drawable.sci_fi);
                break;
            case "Sport": movie.setImgResource(R.drawable.sport);
                break;
            case "Thriller": movie.setImgResource(R.drawable.thriller);
                break;
            default: movie.setImgResource(R.drawable.no_image);
                break;
        }
        holder.img.setImageResource(movie.getImgResource());

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailsIntent = new Intent(getContext(), DetailsActivity.class);
                detailsIntent.putExtra(DETAIL_CONTENT, movie.getTitle());
                detailsIntent.putExtra(IMAGE, movie.getImgResource());
                if(getContext() instanceof OverviewActivity)
                {
                    ((OverviewActivity) getContext()).ToDetailActivity(detailsIntent);
                }
            }
        });
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent editIntent = new Intent(getContext(), EditActivity.class);
                editIntent.putExtra(EDIT_CONTENT, movie.getTitle());
                if(getContext() instanceof OverviewActivity)
                {
                    ((OverviewActivity) getContext()).ToEditActivity(editIntent);
                }
                return true;
            }
        });

        return convertView;
    }
}