package emmaRolsted.au541800;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import emmaRolsted.au541800.Database.Movie;

import static android.text.Layout.JUSTIFICATION_MODE_INTER_WORD;

public class DetailsActivity extends AppCompatActivity {

    private TextView title, rating, userRating, plot, userComments, genres, status;
    private ImageView img;
    private Button OK, Delete;
    private CheckBox movieStatus;
    private boolean bound = false;
    private MovieService movieService;
    Movie movie = new Movie();

    String movieTitle;
    Integer image;
    Drawable drawable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        Initialize();

        OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_OK);
                finish();
            }
        });

        movieTitle = getIntent().getStringExtra(GlobalVariables.DETAIL_CONTENT);
        image = getIntent().getIntExtra(GlobalVariables.IMAGE,R.drawable.no_image);

        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bound)
                {
                    movieService.RemoveMovie(movie.getTitle());
                    finish();
                }
            }
        });
    }

    private void updateUI(){
        if(movie==null) {
            return;
        }
        //Setting up movies
        title.setText(movie.getTitle());
        rating.setText((getString(R.string.IMDB)+movie.getRating()));
        if(movie.getUserRating() == 0.0)
        {
            userRating.setText(String.format("%s%s", getString(R.string.UserRating), getString(R.string.none)));
        }
        else if(movie.getUserRating()==10.0)
        {
            userRating.setText(String.format("%s%s", getString(R.string.UserRating), getString(R.string.ten)));
        }
        else
        {
            userRating.setText(String.format("%s%s", getString(R.string.UserRating),
                    String.valueOf(movie.getUserRating())));
        }

        movieStatus.setChecked(movie.getWatched());
        status.setText(getString(R.string.Status_true));
        plot.setText(movie.getPlot());

        drawable = getResources().getDrawable(image);
        img.setImageDrawable(drawable);

        //Allign text movie if plot if the build version is okay
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            plot.setJustificationMode(JUSTIFICATION_MODE_INTER_WORD);
        }
        genres.setText(movie.getGenre());
        if(movie.getUserComments().isEmpty())
        {
            userComments.setText("");
        }
        else {
            userComments.setText(String.format("%s%s", getString(R.string.UserComments),
                    movie.getUserComments()));
        }
    }

    private ServiceConnection movieServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MovieService.LocalBinder binder = (MovieService.LocalBinder) service;
            movieService = binder.getService();
            bound = true;
            movie = movieService.GetMovie(movieTitle);
            updateUI();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e("DetailsActivity", "onServiceDisconnected");
            bound = false;
        }
    };

    @Override
    protected void onStart(){
        super.onStart();
        bindToMovieService();
    }

    void bindToMovieService() {
        bindService(new Intent(this.getApplicationContext(),
                MovieService.class), movieServiceConnection, Context.BIND_AUTO_CREATE);
        bound = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        unBindFromMovieService();
    }

    void unBindFromMovieService() {
        if (bound) {
            unbindService(movieServiceConnection);
            bound = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void Initialize()
    {
        //Initializing UI elements
        title = findViewById(R.id.TitleDetails);
        rating = findViewById(R.id.RatingDetails);
        userRating = findViewById(R.id.UserRatingDetails);
        plot = findViewById(R.id.PlotDetails);
        userComments = findViewById(R.id.UserCommentsDetails);
        genres = findViewById(R.id.GenreDetails);
        status = findViewById(R.id.StatusDetails);

        img = findViewById(R.id.ImgDetails);
        OK = findViewById(R.id.ok);
        movieStatus = findViewById(R.id.cbDetails);

        Delete = findViewById(R.id.deleteBnt);
    }


}
