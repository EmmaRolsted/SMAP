package emmaRolsted.au541800;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.Random;

import emmaRolsted.au541800.Database.AppDatabase;
import emmaRolsted.au541800.Database.Movie;

import static emmaRolsted.au541800.GlobalVariables.BROADCAST_MOVIES_CREATED;
import static emmaRolsted.au541800.GlobalVariables.BROADCAST_MOVIES_UPDATED;
import static emmaRolsted.au541800.GlobalVariables.BROADCAST_MOVIE_DELETED;
import static emmaRolsted.au541800.GlobalVariables.CHANNEL_ID;
import static emmaRolsted.au541800.GlobalVariables.ID;
import static emmaRolsted.au541800.GlobalVariables.TAG;

//Reference:
//https://developer.android.com/guide/components/bound-services
public class MovieService extends Service {
    AppDatabase db;
    private boolean isStarted = false;

    private final IBinder binder = new LocalBinder();

    @Override
    public void onCreate() {
        super.onCreate();
        CreateMovies();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if(!isStarted && intent != null)
        {
            CreateNotification();
            new LongOperation().execute();
        }
        else {
            Log.d(TAG, "Movie service already started");

        }
        return START_STICKY;
    }

    public class LocalBinder extends Binder {
        MovieService getService() {
            return MovieService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    public String MakeURL(String title)
    {
        String searchableTitle = title.replace(" ","+");
        return "https://www.omdbapi.com/?t="+searchableTitle+"&apikey=210dc008";
    }

    //Methods for clients:
    //References:
    // https://codinginflow.com/tutorials/android/volley/simple-get-request
    // https://developer.android.com/training/volley/request
    public void AddMovie(String title){
        final Gson gson = new Gson();
        StringRequest request = new StringRequest
                (Request.Method.GET, MakeURL(title), new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "On Response");
                        if(response.contains("Movie not found!"))
                        {
                            Log.d(TAG,"Error: Could not find movie");
                            Toast toast = Toast.makeText(getApplicationContext(),
                                    getString(R.string.toast_movieNotFound),
                                    Toast.LENGTH_LONG);
                            toast.show();
                        }
                        else {
                            Movie movie = gson.fromJson(response, Movie.class);
                            Log.d(TAG, "Added: "+movie.getTitle());
                            db = AppDatabase.getAppDatabase(getApplicationContext());
                            db.movieDao().insert(movie);
                            sendBroadcast("AddMovie");

                            Toast toast = Toast.makeText(getApplicationContext(), getString(R.string.db_movieAdded),
                                    Toast.LENGTH_LONG);
                            toast.show();
                        }
                    }

                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e(TAG, "Error: "+error);
                    }
                });
        VolleySingleton.getInstance(this).addToRequestQueue(request);
    }

    public void RemoveMovie(String title){
        Movie m = GetMovie(title);
        db.movieDao().delete(m);

        sendBroadcast("Remove");
    }

    public void UpdateMovie(Movie movie){
        db = AppDatabase.getAppDatabase(getApplicationContext());
        db.movieDao().update(movie);

        sendBroadcast("Update");
    }


    public Movie GetMovie(String title)
    {
        return db.movieDao().findByTitle(title);
    }

    public ArrayList<Movie> GetAllMovies(){
        return new ArrayList<>(db.movieDao().getAllMovies());
    }

    //References:
    // https://developer.android.com/training/notify-user/channels
    // https://developer.android.com/training/notify-user/build-notification
    // https://stackoverflow.com/questions/6397754/android-implementing-startforeground-for-a-service
    private void CreateNotification()
    {
        isStarted = true;
        db = AppDatabase.getAppDatabase(getApplicationContext());
        ArrayList<Movie> unWatched = new ArrayList<>(db.movieDao().getUnwatchedMovies(0));

        if(unWatched.size()!=0) {
            Movie randomMovie = unWatched.get(new Random().nextInt(unWatched.size()));
            String text =
                    getString(R.string.notification)+randomMovie.getTitle()+"!\n\n"
                            +randomMovie.getPlot();

            Notification notification =
                    new NotificationCompat.Builder(this, CHANNEL_ID)
                            .setSmallIcon(R.drawable.movie_notification)
                            .setContentTitle(getString(R.string.notification_name))
                            .setContentText(getString(R.string.notification)+randomMovie.getTitle()+"!")
                            .setStyle(new NotificationCompat.BigTextStyle()
                                    .bigText(text))
                            .build();

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

                int importance = NotificationManager.IMPORTANCE_HIGH;
                String name ="movie_notification";
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
                NotificationManager notificationManager = getSystemService(NotificationManager.class);
                notificationManager.createNotificationChannel(channel);
            }
            startForeground(ID, notification);
        }
        else
        {

            Notification notification =
                    new NotificationCompat.Builder(this, CHANNEL_ID)
                            .setSmallIcon(R.drawable.movie_notification)
                            .setContentTitle(getString(R.string.notification_name))
                            .setContentText(getString(R.string.notification_empty))
                            .build();

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

                int importance = NotificationManager.IMPORTANCE_HIGH;
                String name ="movie_notification";
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
                NotificationManager notificationManager = getSystemService(NotificationManager.class);
                notificationManager.createNotificationChannel(channel);
            }
            startForeground(ID, notification);
        }
    }

    //Reference:
    // https://stackoverflow.com/questions/9671546/asynctask-android-example
    private class LongOperation extends AsyncTask<String, String, String>{

        @Override
        protected String doInBackground(String... strings) {
            while (isStarted)
            {
                try {
                    CreateNotification();
                    Thread.sleep(120000); //Sleep for 2 minutes
                    //Thread.sleep(10000); //Sleep for 10 seconds to test the functionality
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }

    //Reference:
    //https://www.techotopia.com/index.php/Android_Broadcast_Intents_and_Broadcast_Receivers
    //https://gist.github.com/Antarix/8131277
    private void sendBroadcast(String functionName){
        Intent intent = new Intent();
        intent.setAction(BROADCAST_MOVIES_UPDATED);
        Log.d(TAG, "Broadcast coming from: "+functionName);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
    public void CreateMovies()
    {
        //Setting the movie up, with the default image
        Movie movie1 = new Movie("Avengers: The Infinity War",
                "8.5",
                0.0,
                false,
                "The Avengers and their allies must be willing to sacrifice all in an attempt to defeat the powerful Thanos before his blitz of devastation and ruin puts an end to the universe.",
                "Adventure, Action, Fantasy, Sci-Fi",
                "",
                R.drawable.no_image);
        Movie movie2 = new Movie(
                "Bohemian Rhapsody",
                "8.3",
                0.0,
                false,
                "The story of the legendary rock band Queen and lead singer Freddie Mercury, leading up to their famous performance at Live Aid (1985).",
                "Music, Biography, Drama",
                "",
                R.drawable.no_image);
        Movie movie3 = new Movie(
                "A Star is Born",
                "7.9",
                0.0,
                false,
                "A musician helps a young singer find fame, even as age and alcoholism send his own career into a downward spiral.",
                "Romance, Music, Drama",
                "",
                R.drawable.no_image);
        Movie movie4 = new Movie(
                "Deadpool 2",
                "7.8",
                0.0,
                false,
                "Foul-mouthed mutant mercenary Wade Wilson (AKA. Deadpool), brings together a team of fellow mutant rogues to protect a young boy with supernatural abilities from the brutal, time-traveling cyborg, Cable.",
                "Action, Adventure, Comedy, Sci-Fi",
                "",
                R.drawable.no_image);
        Movie movie5 = new Movie(
                "Incredibles 2",
                "7.8",
                0.0,
                false,
                "The Incredibles hero family takes on a new mission, which involves a change in family roles: Bob Parr (Mr Incredible) must manage the house while his wife Helen (Elastigirl) goes out to save the world.",
                "Animation, Action, Adventure, Comedy, Family, Sci-Fi",
                "",
                R.drawable.no_image);
        Movie movie6 = new Movie(
                "Mission: Impossible - Fallout",
                "7.8",
                0.0,
                false,
                "Ethan Hunt and his IMF team, along with some familiar allies, race against time after a mission gone wrong.",
                "Action, Adventure, Thriller",
                "",
                R.drawable.no_image);
        Movie movie7 = new Movie(
                "Creed II",
                "7.5",
                0.0,
                false,
                "Under the tutelage of Rocky Balboa, heavyweight contender Adonis Creed faces off" +
                        " against Viktor Drago, son of Ivan Drago",
                "Sport, Drama",
                "",
                R.drawable.no_image);
        Movie movie8 = new Movie(
                "Ready Player One",
                "7.5",
                0.0,
                false,
                "When the creator of a virtual reality world called the OASIS dies, he releases a video in which he challenges all OASIS users to find his Easter Egg, which will give the finder his fortune.",
                "Sci-Fi, Action, Adventure",
                "",
                R.drawable.no_image);
        Movie movie9 = new Movie(
                "First Man",
                "7.5",
                0.0,
                false,
                "A look at the life of the astronaut, Neil Armstrong, and the legendary space mission that led him to become the first man to walk on the Moon on July 20, 1969.",
                "Biography, Drama, History",
                "",
                R.drawable.no_image);
        Movie movie10 = new Movie(
                "Black Panther",
                "7.4",
                0.0,
                false,
                "T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future and must confront a challenger from his country's past.",
                "Action, Adventure, Sci-Fi",
                "",
                R.drawable.no_image);
        Movie movie11 = new Movie(
                "Aquaman",
                "7.4",
                0.0,
                false,
                "Arthur Curry, the human-born heir to the underwater kingdom of Atlantis, goes on a quest to prevent a war between the worlds of ocean and land.\n",
                "Fantasy, Action, Adventure, Sci-Fi",
                "",
                R.drawable.no_image);

        db = AppDatabase.getAppDatabase(getApplicationContext());

        db.movieDao().insert(movie1);
        db.movieDao().insert(movie2);
        db.movieDao().insert(movie3);
        db.movieDao().insert(movie4);
        db.movieDao().insert(movie5);
        db.movieDao().insert(movie6);
        db.movieDao().insert(movie7);
        db.movieDao().insert(movie8);
        db.movieDao().insert(movie9);
        db.movieDao().insert(movie10);
        db.movieDao().insert(movie11);
    }
}


