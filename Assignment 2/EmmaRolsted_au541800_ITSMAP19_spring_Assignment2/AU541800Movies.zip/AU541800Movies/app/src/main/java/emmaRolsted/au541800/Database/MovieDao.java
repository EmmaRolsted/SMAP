package emmaRolsted.au541800.Database;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.ArrayList;
import java.util.List;

//References:
// https://medium.com/@ajaysaini.official/building-database-with-room-persistence-library-ecf7d0b8f3e9?fbclid=IwAR0Yip3Knj7te9gdbauTe-i9clwVAU-q5McChvrJFhtJekHHv56XrJ-cTaU
@Dao
public interface MovieDao {
    @Query("SELECT * FROM MOVIE ORDER BY title") // Sort movies by title
    List<Movie> getAllMovies();

    @Query("SELECT * FROM movie where title LIKE  :title")
    Movie findByTitle(String title);

    @Query("SELECT * FROM movie where watched LIKE :status")
    List<Movie> getUnwatchedMovies(Integer status);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Movie movie);

    @Delete
    void delete(Movie movie);

    @Update
    void update(Movie movie);


}
